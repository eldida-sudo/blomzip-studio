import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { initialImages, type ImageItem } from "./data/demoImages";
import { getPlaceById, listCanonicalPlaces } from "./data/canonicalPlaces";
import { EntryReview } from "./components/EntryReview";
import { LivingMapPanel } from "./components/LivingMapPanel";
import { PlaceMapReference } from "./components/PlaceMapReference";
import { MockObservationEngine, type ObservationEngine } from "./components/observationEngine";
import { ZipImportPanel } from "./components/ZipImportPanel";
import type {
  DraftVisit,
  DraftWorkspace,
  Entry,
  EntrySuggestionCategory,
  ImageRecord,
  Visit,
} from "./models/blomzip";
import {
  createArchiveStateSnapshot,
  loadArchiveState,
  saveArchiveState,
} from "./utils/archivePersistence";
import {
  collectBlobThumbnailUrlsFromVisit,
  hydrateArchiveStateThumbnails,
  persistArchiveThumbnailBinaries,
} from "./utils/archiveThumbnailStore";
import {
  createDraftImportSummary,
  createDraftVisitFromState,
  loadDraftWorkspace,
  saveDraftWorkspace,
  upsertDraftVisit,
} from "./utils/draftWorkspace";
import { discoverPlacesVisionSummary } from "./utils/discoverPlacesVisionEngine";
import {
  createBatchImportOutcome,
  formatBatchImportSummary,
  mergeImportedVisit,
  type BatchImportOutcome,
} from "./utils/mergeImportedVisit";
import { createPublishReadyVisitOutput } from "./utils/publishReadyOutput";
import { isEntryPrivacyBlocked } from "./utils/privacy";
import { createThumbnailUrlForRecord } from "./utils/createThumbnailUrls";
import { parseCaptureDate } from "./utils/captureDate";
import {
  getEntryEditorialRecommendations,
  withAutomaticAnalysisSuggestions,
} from "./utils/entryRecommendations";
import { applyStoryRecommendations } from "./utils/storyRecommendations";
import { createVisionProvider } from "./utils/visionProvider";
import type { VisionPlaceCandidateGroup } from "./utils/discoverPlacesVisionEngine";
import type { ZipImportSummary } from "./utils/readZipImages";
import "./App.css";

declare global {
  interface Window {
    __BLOMZIP_DEBUG_THUMBNAILS__?: boolean;
  }
}

type ViewFilter = "all" | "favorites" | "hero";

type SuggestionFilter = "all" | EntrySuggestionCategory;

type BatchImportFeedback = BatchImportOutcome;

type ReviewQueueMode = "story-first" | "needs-confirmation";

interface InboxSuggestionItem {
  entryId: string;
  index: number;
  filename: string;
  confidence?: number;
}

interface InboxSuggestionGroup {
  key: string;
  title: string;
  items: InboxSuggestionItem[];
}

interface PlaceAssignmentResult {
  visit: Visit;
  assignedCount: number;
}

type PrimaryArchiveAction =
  | "import"
  | "review-ai"
  | "review"
  | "story"
  | "finalize"
  | "publish";

type TimelineRow =
  | {
      type: "header";
      dateKey: string;
      label: string;
    }
  | {
      type: "card";
      item: {
        image: ImageItem;
        index: number;
        entry: Entry | undefined;
        imageRecord: ImageRecord | undefined;
      };
    };

const SUGGESTION_FILTER_OPTIONS: Array<{ value: SuggestionFilter; label: string }> = [
  { value: "all", label: "All AI categories" },
  { value: "story-candidate", label: "Story recommendations" },
  { value: "hero-candidate", label: "Hero candidates" },
  { value: "favorite-candidate", label: "Favorite candidates" },
  { value: "strong-change", label: "Strong change / comparison value" },
  { value: "overview-image", label: "Overview images" },
  { value: "detail-image", label: "Detail images" },
  { value: "by-place", label: "By place" },
  { value: "needs-review", label: "Needs review" },
  { value: "low-confidence", label: "Low confidence" },
  { value: "possible-duplicates", label: "Possible duplicates" },
];

function getSuggestionChipLabel(category: EntrySuggestionCategory): string {
  switch (category) {
    case "story-candidate":
      return "AI: Story";
    case "hero-candidate":
      return "AI: Hero";
    case "favorite-candidate":
      return "AI: Favorite";
    case "strong-change":
      return "AI: Change";
    case "overview-image":
      return "AI: Overview";
    case "detail-image":
      return "AI: Detail";
    case "by-place":
      return "AI: Place";
    case "needs-review":
      return "AI: Needs review";
    case "low-confidence":
      return "AI: Low confidence";
    case "possible-duplicates":
      return "AI: Duplicate";
    default:
      return "AI";
  }
}

function createDraftGalleryImage(options: {
  visit: Visit;
  entry: Entry;
  imageRecord: ImageRecord | undefined;
  importBatchFileName: string | undefined;
  index: number;
}): ImageItem {
  const { visit, entry, imageRecord, importBatchFileName, index } = options;
  const filename = imageRecord?.filename ?? `entry-${index + 1}`;
  const placeLabel = imageRecord?.placeId
    ? getPlaceById(imageRecord.placeId)?.displayName ?? "Unknown"
    : "Unknown";

  return {
    id: index + 1,
    title: filename,
    collection: "Imported ZIP",
    date: visit.date,
    tags: [...entry.tags],
    favorite: Boolean(entry.favorite),
    hero: Boolean(entry.hero),
    notes: entry.notes,
    color: "linear-gradient(135deg, #6a7878, #d6d6c8)",
    src: createThumbnailUrlForRecord(imageRecord) ?? "",
    alt: filename,
    storyRole: entry.storySelected ? "Selected for Courtyard Story" : entry.reviewed ? "Reviewed import entry" : "Pending import entry",
    season: "Imported",
    location: placeLabel,
    mood: "",
    material: "",
    light: "",
    composition: "",
    importSource: importBatchFileName ? `ZIP import (${importBatchFileName})` : `ZIP import (${visit.id})`,
  };
}

// A single approval action must never assign a place to more than this many
// visible, individually reviewed photographs, even when the underlying
// discovery cluster contains far more members.
const MAX_PLACE_APPROVAL_BATCH_SIZE = 10;

function assignCanonicalPlaceToVisionGroup(options: {
  visit: Visit;
  group: VisionPlaceCandidateGroup;
  canonicalPlaceId: string;
}): PlaceAssignmentResult {
  const { visit, group, canonicalPlaceId } = options;
  const targetRecordIds = new Set(group.imageRecordIds);
  let assignedCount = 0;

  const nextImageRecords = (visit.imageRecords ?? []).map((record) => {
    if (!targetRecordIds.has(record.id)) {
      return record;
    }

    // Approved assignments are immutable; never overwrite an existing place id.
    if (record.placeId) {
      return record;
    }

    assignedCount += 1;

    return {
      ...record,
      placeId: canonicalPlaceId,
    };
  });

  if (assignedCount === 0) {
    return {
      visit,
      assignedCount,
    };
  }

  return {
    visit: {
      ...visit,
      imageRecords: nextImageRecords,
    },
    assignedCount,
  };
}

function createGalleryImagesFromVisit(visit: Visit): ImageItem[] {
  const imageRecordsById = new Map((visit.imageRecords ?? []).map((record) => [record.id, record]));
  const importBatchesById = new Map((visit.importBatches ?? []).map((batch) => [batch.id, batch]));

  return visit.entries.map((entry, index) =>
    createDraftGalleryImage({
      visit,
      entry,
      imageRecord: imageRecordsById.get(entry.imageRecordId),
      importBatchFileName: importBatchesById.get(imageRecordsById.get(entry.imageRecordId)?.importBatchId ?? "")?.fileName,
      index,
    })
  );
}

function formatDateLabel(value: string | undefined): string {
  const parsed = parseCaptureDate(value);
  if (!parsed) {
    return "Undated";
  }

  return parsed.toLocaleDateString(undefined, {
    year: "numeric",
    month: "short",
    day: "numeric",
  });
}

function formatDateRange(minDate: string | undefined, maxDate: string | undefined): string {
  if (!minDate || !maxDate) {
    return "Undated";
  }

  if (minDate === maxDate) {
    return formatDateLabel(minDate);
  }

  return `${formatDateLabel(minDate)} - ${formatDateLabel(maxDate)}`;
}

function formatPercent(value: number): string {
  return `${Math.round(value * 100)}%`;
}

function getDateKeyFromCaptureDate(captureDate?: string): string {
  const parsed = parseCaptureDate(captureDate);
  if (!parsed) {
    return "undated";
  }

  return parsed.toISOString().slice(0, 10);
}

function getDateHeaderLabel(dateKey: string): string {
  if (dateKey === "undated") {
    return "Undated";
  }

  return formatDateLabel(dateKey);
}

function mapSuggestionCategoryLabel(category: EntrySuggestionCategory): string {
  switch (category) {
    case "story-candidate":
      return "story";
    case "hero-candidate":
      return "hero";
    case "favorite-candidate":
      return "favorite";
    case "possible-duplicates":
      return "duplicate";
    case "by-place":
      return "place";
    case "strong-change":
      return "observation";
    case "overview-image":
      return "overview";
    case "detail-image":
      return "detail";
    case "needs-review":
      return "needs review";
    case "low-confidence":
      return "low confidence";
    default:
      return "suggestion";
  }
}

function getQueuePriority(entry: Entry): number {
  const categories = entry.analysisSuggestions?.categories ?? [];

  if (categories.includes("story-candidate")) {
    return 0;
  }

  if (categories.includes("hero-candidate")) {
    return 1;
  }

  if (categories.includes("favorite-candidate")) {
    return 2;
  }

  return 3;
}

function isNormalImagePath(value: string): boolean {
  return Boolean(value) && !value.startsWith("data:") && !value.startsWith("blob:") && !value.startsWith("http://") && !value.startsWith("https://");
}

export function getGalleryCardDisplayTitle(image: ImageItem, imageRecord?: Pick<ImageRecord, "filename"> | null) {
  if (imageRecord?.filename) {
    return imageRecord.filename;
  }

  if (image.title) {
    return image.title;
  }

  const normalizedSrc = image.src?.trim();
  if (normalizedSrc && isNormalImagePath(normalizedSrc)) {
    return normalizedSrc.split("/").filter(Boolean).pop() ?? normalizedSrc;
  }

  return image.title;
}

export function resolveGalleryThumbnailSrc(
  image: ImageItem,
  imageRecord?: Pick<ImageRecord, "thumbnailUrl" | "filename"> | null
) {
  const normalizedSrc = image.src?.trim();

  if (normalizedSrc) {
    return normalizedSrc;
  }

  return createThumbnailUrlForRecord(imageRecord) ?? "";
}

function collectManagedBlobUrls(importVisit: Visit | null, workspace: DraftWorkspace): Set<string> {
  const urls = new Set<string>();

  for (const url of collectBlobThumbnailUrlsFromVisit(importVisit)) {
    urls.add(url);
  }

  for (const draft of workspace.drafts) {
    for (const url of collectBlobThumbnailUrlsFromVisit(draft.visit)) {
      urls.add(url);
    }
  }

  return urls;
}

function appThumbnailDebug(event: string, details: Record<string, unknown>) {
  if (typeof window === "undefined") {
    return;
  }

  if (!import.meta.env?.DEV || !window.__BLOMZIP_DEBUG_THUMBNAILS__) {
    return;
  }

  console.debug("[blomzip-app-thumbnails]", event, details);
}

function App() {
  const [images, setImages] = useState<ImageItem[]>(initialImages);
  const [search, setSearch] = useState("");
  const [collectionFilter, setCollectionFilter] = useState("All");
  const [viewFilter, setViewFilter] = useState<ViewFilter>("all");
  const [suggestionFilter, setSuggestionFilter] = useState<SuggestionFilter>("all");
  const [archivePlaceFilter, setArchivePlaceFilter] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<ImageItem | null>(null);
  const [importSummary, setImportSummary] = useState<ZipImportSummary | null>(null);
  const [importVisit, setImportVisit] = useState<Visit | null>(null);
  const [latestImportedBatchIdForVision, setLatestImportedBatchIdForVision] = useState<string | null>(null);
  const [activeBatchFilterId, setActiveBatchFilterId] = useState<string | null>(null);
  const [isBatchProvenanceExpanded, setIsBatchProvenanceExpanded] = useState<boolean | null>(null);
  const [lastBatchImportFeedback, setLastBatchImportFeedback] = useState<BatchImportFeedback | null>(null);
  const [draftWorkspace, setDraftWorkspace] = useState<DraftWorkspace>(() => loadDraftWorkspace());
  const [isArchiveHydrated, setIsArchiveHydrated] = useState(false);
  const [isReviewingEntries, setIsReviewingEntries] = useState(false);
  const [reviewStartIndex, setReviewStartIndex] = useState(0);
  const [activeVisionGroupId, setActiveVisionGroupId] = useState<string | null>(null);
  const [overviewObservationEngine] = useState<ObservationEngine>(() => new MockObservationEngine());
  const [visionProvider] = useState(() => createVisionProvider());
  const [batchVisionProgress, setBatchVisionProgress] = useState<{
    completed: number;
    total: number;
    failed: number;
    running: boolean;
  } | null>(null);
  const [selectedPlaceByVisionGroupId, setSelectedPlaceByVisionGroupId] = useState<Record<string, string>>({});
  const [excludedImageIdsByVisionGroupId, setExcludedImageIdsByVisionGroupId] = useState<Record<string, string[]>>({});
  const [reviewBatchByVisionGroupId, setReviewBatchByVisionGroupId] = useState<Record<string, string[]>>({});
  const [placeAssignmentFeedback, setPlaceAssignmentFeedback] = useState<string | null>(null);
  const [openPlaceMapGroupId, setOpenPlaceMapGroupId] = useState<string | null>(null);
  const hasAppliedStudioImagesRef = useRef(false);
  const sidebarImportSectionRef = useRef<HTMLElement | null>(null);
  const visionSummaryRef = useRef<HTMLElement | null>(null);
  const managedThumbnailObjectUrlsRef = useRef<Set<string>>(new Set());
  const latestImportVisitRef = useRef<Visit | null>(null);
  const savedDrafts = draftWorkspace.drafts;
  const hasExportableArchive = Boolean(importVisit || savedDrafts.length > 0);

  function commitImportVisit(nextOrUpdater: Visit | null | ((current: Visit | null) => Visit | null)) {
    const nextVisit = typeof nextOrUpdater === "function"
      ? nextOrUpdater(latestImportVisitRef.current)
      : nextOrUpdater;

    latestImportVisitRef.current = nextVisit;
    setImportVisit(nextVisit);
  }

  useEffect(() => {
    let isCancelled = false;

    void loadArchiveState().then(async (snapshot) => {
      if (isCancelled) {
        return;
      }

      if (snapshot) {
        let nextSnapshot = snapshot;

        try {
          const hydrated = await hydrateArchiveStateThumbnails(snapshot);
          if (isCancelled) {
            hydrated.objectUrls.forEach((url) => URL.revokeObjectURL(url));
            return;
          }

          hydrated.objectUrls.forEach((url) => managedThumbnailObjectUrlsRef.current.add(url));
          nextSnapshot = hydrated.value;
          appThumbnailDebug("hydrate-applied", {
            hydratedObjectUrlCount: hydrated.objectUrls.length,
            importImageRecordCount: hydrated.value.importVisit?.imageRecords?.length ?? 0,
            importThumbnailCount: hydrated.value.importVisit?.imageRecords?.filter((record) => Boolean(record.thumbnailUrl)).length ?? 0,
          });
        } catch {
          // If thumbnail hydration fails, archive metadata still loads and placeholder thumbnails are used.
          appThumbnailDebug("hydrate-failed", {
            importImageRecordCount: snapshot.importVisit?.imageRecords?.length ?? 0,
          });
        }

        commitImportVisit(nextSnapshot.importVisit);
        setDraftWorkspace(nextSnapshot.draftWorkspace);
      }

      setIsArchiveHydrated(true);
    });

    return () => {
      isCancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!isArchiveHydrated) {
      return;
    }

    saveDraftWorkspace(draftWorkspace);
  }, [draftWorkspace, isArchiveHydrated]);

  useEffect(() => {
    if (!isArchiveHydrated) {
      return;
    }

    void persistArchiveThumbnailBinaries({ importVisit, draftWorkspace }).catch(() => {
      // Archive metadata persistence still works when thumbnail binary storage is unavailable.
    });
  }, [draftWorkspace.drafts, importVisit?.imageRecords, isArchiveHydrated]);

  useEffect(() => {
    if (!isArchiveHydrated) {
      return;
    }

    if (!hasExportableArchive) {
      return;
    }

    appThumbnailDebug("metadata-save", {
      importImageRecordCount: importVisit?.imageRecords?.length ?? 0,
      importThumbnailCount: importVisit?.imageRecords?.filter((record) => Boolean(record.thumbnailUrl)).length ?? 0,
    });

    void saveArchiveState(createArchiveStateSnapshot({ importVisit, draftWorkspace }));
  }, [draftWorkspace, hasExportableArchive, importVisit, isArchiveHydrated]);

  useEffect(() => {
    const activeUrls = collectManagedBlobUrls(importVisit, draftWorkspace);

    managedThumbnailObjectUrlsRef.current.forEach((url) => {
      if (activeUrls.has(url)) {
        return;
      }

      URL.revokeObjectURL(url);
      managedThumbnailObjectUrlsRef.current.delete(url);
    });
  }, [draftWorkspace, importVisit]);

  useEffect(() => {
    return () => {
      managedThumbnailObjectUrlsRef.current.forEach((url) => {
        URL.revokeObjectURL(url);
      });

      managedThumbnailObjectUrlsRef.current.clear();
    };
  }, []);

  function handleImportEntryUpdated(updatedEntry: Entry) {
    commitImportVisit((currentVisit) => {
      if (!currentVisit) {
        return currentVisit;
      }

      return {
        ...currentVisit,
        status: currentVisit.status === "Finalized" ? currentVisit.status : "Review in progress",
        entries: currentVisit.entries.map((entry) =>
          entry.id === updatedEntry.id ? updatedEntry : entry
        ),
      };
    });
  }

  function handleEntryReviewImageRecordPlaceChanged(imageRecordId: string, placeId: string | null) {
    commitImportVisit((currentVisit) => {
      if (!currentVisit) {
        return currentVisit;
      }

      return {
        ...currentVisit,
        imageRecords: (currentVisit.imageRecords ?? []).map((record) => {
          if (record.id !== imageRecordId) {
            return record;
          }

          if (placeId === null) {
            const { placeId: _removedPlaceId, ...recordWithoutPlace } = record;
            return recordWithoutPlace;
          }

          return { ...record, placeId };
        }),
      };
    });
  }

  function handleStorySelectionFromOverview(index: number) {
    commitImportVisit((currentVisit) => {
      if (!currentVisit) {
        return currentVisit;
      }

      const targetEntry = currentVisit.entries[index];
      if (!targetEntry) {
        return currentVisit;
      }

      const storySelected = !targetEntry.storySelected;

      return {
        ...currentVisit,
        status: currentVisit.status === "Finalized" ? currentVisit.status : "Review in progress",
        entries: currentVisit.entries.map((entryItem, entryIndex) =>
          entryIndex === index
            ? {
                ...entryItem,
                storySelected,
                updatedAt: new Date().toISOString(),
              }
            : entryItem
        ),
      };
    });
  }

  function handleVisitFinalized(finalizedVisit: Visit) {
    commitImportVisit(finalizedVisit);
    setIsReviewingEntries(false);
  }

  function handleSaveDraft() {
    if (!importVisit) {
      return;
    }

    const draftImages = createGalleryImagesFromVisit(importVisit);

    const draftVisit = createDraftVisitFromState({
      visit: {
        ...importVisit,
        status: importVisit.status === "Finalized" ? "Finalized" : "Review in progress",
      },
      studioImages: draftImages,
    });

    setDraftWorkspace((currentWorkspace) => upsertDraftVisit(currentWorkspace, draftVisit));
  }

  function handleLoadDraft(draftVisit: DraftVisit) {
    const draftImages = draftVisit.studioImages.length > 0
      ? draftVisit.studioImages
      : createGalleryImagesFromVisit(draftVisit.visit);

    hasAppliedStudioImagesRef.current = true;
    setImages(draftImages);
    setImportSummary(createDraftImportSummary(draftVisit));
    commitImportVisit(withAutomaticAnalysisSuggestions(draftVisit.visit, overviewObservationEngine));
    setLatestImportedBatchIdForVision(null);
    setReviewStartIndex(0);
    setIsReviewingEntries(true);
    setSelectedImage(null);
    setDraftWorkspace((currentWorkspace) => ({
      ...currentWorkspace,
      activeDraftId: draftVisit.id,
    }));
  }

  useEffect(() => {
    fetch("/data/images.json")
      .then((response) => {
        if (!response.ok) throw new Error("Could not load imported images");
        return response.json();
      })
      .then((data: ImageItem[]) => {
        if (hasAppliedStudioImagesRef.current) {
          return;
        }

        setImages(data);
        hasAppliedStudioImagesRef.current = true;
      })
      .catch(() => {
        if (hasAppliedStudioImagesRef.current) {
          return;
        }

        setImages(initialImages);
        hasAppliedStudioImagesRef.current = true;
      });
  }, []);

  const gallerySourceImages = useMemo(
    () => (importVisit ? createGalleryImagesFromVisit(importVisit) : images),
    [importVisit, images]
  );

  const imageRecordsById = useMemo(
    () => new Map((importVisit?.imageRecords ?? []).map((record) => [record.id, record])),
    [importVisit]
  );

  const importBatchesById = useMemo(
    () => new Map((importVisit?.importBatches ?? []).map((batch) => [batch.id, batch])),
    [importVisit]
  );

  const collections = useMemo(() => {
    return ["All", ...Array.from(new Set(gallerySourceImages.map((image) => image.collection)))];
  }, [gallerySourceImages]);

  const galleryItems = useMemo(
    () => gallerySourceImages.map((image, index) => {
      const entry = importVisit?.entries[index];
      const imageRecord = entry ? imageRecordsById.get(entry.imageRecordId) : undefined;

      return {
        image,
        index,
        entry,
        imageRecord,
        importBatch: imageRecord?.importBatchId ? importBatchesById.get(imageRecord.importBatchId) : undefined,
      };
    }),
    [gallerySourceImages, importVisit, imageRecordsById, importBatchesById]
  );

  const filteredImages = galleryItems.filter(({ image, entry, imageRecord }) => {
    const searchText =
      `${image.title} ${image.collection} ${image.tags.join(" ")} ${image.notes} ${image.storyRole} ${image.season} ${image.location} ${image.mood} ${image.material} ${image.light} ${image.composition} ${image.importSource}`.toLowerCase();

    const matchesSearch = searchText.includes(search.toLowerCase());
    const matchesCollection =
      collectionFilter === "All" || image.collection === collectionFilter;

    const matchesViewFilter =
      viewFilter === "all" ||
      (viewFilter === "favorites" && image.favorite) ||
      (viewFilter === "hero" && image.hero);

    const entrySuggestionCategories = entry?.analysisSuggestions?.categories ?? [];
    const matchesSuggestionFilter =
      suggestionFilter === "all" || entrySuggestionCategories.includes(suggestionFilter);

    const matchesBatchFilter = !activeBatchFilterId || imageRecord?.importBatchId === activeBatchFilterId;
    const matchesPlaceFilter = archivePlaceFilter === null || imageRecord?.placeId === archivePlaceFilter;

    return matchesSearch && matchesCollection && matchesViewFilter && matchesSuggestionFilter && matchesBatchFilter && matchesPlaceFilter;
  });

  const archiveDateRange = useMemo(() => {
    if (!importVisit?.imageRecords || importVisit.imageRecords.length === 0) {
      return "No dated captures yet";
    }

    const datedValues = importVisit.imageRecords
      .map((record) => {
        return parseCaptureDate(record.captureDate)?.toISOString().slice(0, 10) ?? null;
      })
      .filter((value): value is string => value !== null)
      .sort((left, right) => left.localeCompare(right));

    if (datedValues.length === 0) {
      return "No dated captures yet";
    }

    return formatDateRange(datedValues[0], datedValues[datedValues.length - 1]);
  }, [importVisit]);

  const archiveStats = useMemo(() => {
    const entries = importVisit?.entries ?? [];
    const totalPhotographs = importVisit?.imageRecords?.length ?? gallerySourceImages.length;
    const importBatchCount = importVisit?.importBatches?.length ?? 0;
    const storySelected = entries.filter((entry) => entry.storySelected).length;
    const heroImages = entries.filter((entry) => entry.hero).length;
    const favoriteImages = entries.filter((entry) => entry.favorite).length;
    const waitingReview = entries.filter((entry) => !entry.reviewed).length;
    const aiSuggestionsWaiting = entries.filter(
      (entry) => Boolean(entry.analysisSuggestions) && !entry.reviewed
    ).length;

    return {
      totalPhotographs,
      importBatchCount,
      storySelected,
      heroImages,
      favoriteImages,
      waitingReview,
      aiSuggestionsWaiting,
    };
  }, [importVisit, gallerySourceImages.length]);

  const batchOverview = useMemo(() => {
    if (!importVisit?.importBatches) {
      return [];
    }

    const entryByImageRecordId = new Map(importVisit.entries.map((entry) => [entry.imageRecordId, entry]));
    const allRecords = importVisit.imageRecords ?? [];

    return [...importVisit.importBatches]
      .sort((left, right) => right.importedAt.localeCompare(left.importedAt))
      .map((batch) => {
        const newRecords = allRecords.filter((record) => record.importBatchId === batch.id);
        // Duplicate-only batches add no new canonical records, so derive capture range from the
        // existing photographs this batch's files were matched to via provenance occurrences.
        const matchedRecords = allRecords.filter((record) =>
          record.additionalOccurrences?.some((occurrence) => occurrence.importBatchId === batch.id)
        );
        const datedValues = [...newRecords, ...matchedRecords]
          .map((record) => {
            return parseCaptureDate(record.captureDate)?.toISOString().slice(0, 10) ?? null;
          })
          .filter((value): value is string => value !== null)
          .sort((left, right) => left.localeCompare(right));
        const reviewedCount = newRecords.filter((record) => entryByImageRecordId.get(record.id)?.reviewed).length;
        const totalCount = newRecords.length;
        const reviewPercent = totalCount > 0 ? Math.round((reviewedCount / totalCount) * 100) : 0;

        return {
          batch,
          captureRange: formatDateRange(datedValues[0], datedValues[datedValues.length - 1]),
          reviewedCount,
          totalCount,
          reviewPercent,
        };
      });
  }, [importVisit]);

  const isBatchProvenanceSectionExpanded = isBatchProvenanceExpanded ?? batchOverview.length <= 1;

  const handleToggleBatchProvenance = useCallback(() => {
    setIsBatchProvenanceExpanded((current) => {
      const currentlyExpanded = current ?? batchOverview.length <= 1;
      return !currentlyExpanded;
    });
  }, [batchOverview.length]);

  const timelineItems = useMemo(() => {
    let lastDateKey: string | null = null;

    return filteredImages.flatMap((item): TimelineRow[] => {
      const dateKey = getDateKeyFromCaptureDate(item.imageRecord?.captureDate);
      const row: TimelineRow[] = [{ type: "card", item }];

      if (dateKey !== lastDateKey) {
        lastDateKey = dateKey;
        row.unshift({
          type: "header",
          dateKey,
          label: getDateHeaderLabel(dateKey),
        });
      }

      return row;
    });
  }, [filteredImages]);

  const reviewedEntryCount = importVisit?.entries.filter((entry) => entry.reviewed).length ?? 0;
  const storySelectedEntryCount = importVisit?.entries.filter((entry) => entry.storySelected).length ?? 0;
  const totalImportedEntries = importVisit?.entries.length ?? 0;
  const isEntryReviewMode = Boolean(isReviewingEntries && importVisit);
  const latestImportBatch = importVisit?.importBatches?.[importVisit.importBatches.length - 1] ?? null;
  const activeGalleryImageId = selectedImage?.id ?? (!isReviewingEntries && importVisit ? gallerySourceImages[reviewStartIndex]?.id : null);
  const canFinalizeVisit = totalImportedEntries > 0 && reviewedEntryCount === totalImportedEntries;
  const privacyBlockedEntryCount = importVisit?.entries.filter((entry) => isEntryPrivacyBlocked(entry)).length ?? 0;
  const canFinalizePrivacySafe = canFinalizeVisit && privacyBlockedEntryCount === 0;
  const isVisitFinalized = importVisit?.status === "Finalized" && privacyBlockedEntryCount === 0;

  const entryViewModels = useMemo(() => {
    if (!importVisit) {
      return [];
    }

    return importVisit.entries.map((entry, index) => {
      const imageRecord = imageRecordsById.get(entry.imageRecordId);

      return {
        entry,
        index,
        imageRecord,
        filename: imageRecord?.filename ?? `Image ${index + 1}`,
      };
    });
  }, [importVisit, imageRecordsById]);

  const aiInboxGroups = useMemo<InboxSuggestionGroup[]>(() => {
    const groupDefinitions: Array<{
      key: string;
      title: string;
      matches: (entry: Entry) => boolean;
    }> = [
      {
        key: "story-candidates",
        title: "Story recommendations",
        matches: (entry) => getEntryEditorialRecommendations(entry).some((recommendation) =>
          recommendation.source === "v0.2"
            ? recommendation.recommendation.kind === "story"
            : recommendation.kind === "story"
        ),
      },
      {
        key: "hero-candidates",
        title: "Hero candidates",
        matches: (entry) => entry.analysisSuggestions?.categories.includes("hero-candidate") ?? false,
      },
      {
        key: "favorite-candidates",
        title: "Favorite candidates",
        matches: (entry) => entry.analysisSuggestions?.categories.includes("favorite-candidate") ?? false,
      },
      {
        key: "possible-duplicates",
        title: "Possible duplicates",
        matches: (entry) => entry.analysisSuggestions?.categories.includes("possible-duplicates") ?? false,
      },
      {
        key: "place-suggestions",
        title: "Place suggestions",
        matches: (entry) => entry.analysisSuggestions?.categories.includes("by-place") ?? false,
      },
      {
        key: "observation-suggestions",
        title: "Observation suggestions",
        matches: (entry) =>
          entry.analysisSuggestions?.categories.some((category) =>
            ["strong-change", "overview-image", "detail-image"].includes(category)
          ) ?? false,
      },
    ];

    return groupDefinitions
      .map((definition) => {
        const items = entryViewModels
          .filter(({ entry }) => definition.matches(entry))
          .map(({ entry, index, filename }) => ({
            entryId: entry.id,
            index,
            filename,
            confidence: entry.analysisSuggestions?.confidence,
          }));

        return {
          key: definition.key,
          title: definition.title,
          items,
        };
      })
      .filter((group) => group.items.length > 0);
  }, [entryViewModels]);

  const storyAnalysisSummary = useMemo(() => {
    const assessedPhotographCount = importVisit?.entries.length ?? 0;
    const recommendationCount = (importVisit?.entries ?? []).filter((entry) =>
      entry.analysisSuggestions?.recommendations?.some((recommendation) => recommendation.kind === "story") ?? false
    ).length;
    const hasRun = (importVisit?.entries ?? []).some((entry) => entry.analysisSuggestions?.recommendations !== undefined);

    return { assessedPhotographCount, recommendationCount, hasRun };
  }, [importVisit]);

  const visionDiscoverySummary = useMemo(() => {
    if (!importVisit) {
      return null;
    }

    return discoverPlacesVisionSummary(importVisit, {
      importBatchId: latestImportedBatchIdForVision,
      fallbackToFullArchive: true,
    });
  }, [importVisit, latestImportedBatchIdForVision]);

  const canonicalPlaces = useMemo(() => listCanonicalPlaces(), []);

  useEffect(() => {
    if (!visionDiscoverySummary) {
      setSelectedPlaceByVisionGroupId({});
      return;
    }

    const visibleGroupIds = new Set(visionDiscoverySummary.candidatePlaceGroups.map((group) => group.id));

    setSelectedPlaceByVisionGroupId((currentSelections) => {
      const nextSelections = Object.fromEntries(
        Object.entries(currentSelections).filter(([groupId]) => visibleGroupIds.has(groupId))
      );

      return nextSelections;
    });
  }, [visionDiscoverySummary]);

  useEffect(() => {
    if (!visionDiscoverySummary) {
      setReviewBatchByVisionGroupId({});
      return;
    }

    setReviewBatchByVisionGroupId((current) => {
      let didChange = false;
      const next: Record<string, string[]> = {};

      visionDiscoverySummary.candidatePlaceGroups.forEach((group) => {
        const excludedImageIds = new Set(excludedImageIdsByVisionGroupId[group.id] ?? []);
        const actionablePoolIds = group.imageRecordIds.filter((recordId) => {
          if (excludedImageIds.has(recordId)) {
            return false;
          }

          const record = imageRecordsById.get(recordId);
          return Boolean(record && !record.placeId);
        });
        const actionablePoolIdSet = new Set(actionablePoolIds);

        const storedBatchIds = current[group.id] ?? [];
        const activeStoredBatchIds = storedBatchIds.filter((recordId) => actionablePoolIdSet.has(recordId));

        if (activeStoredBatchIds.length > 0) {
          next[group.id] = storedBatchIds;
          return;
        }

        const freshBatchIds = actionablePoolIds.slice(0, MAX_PLACE_APPROVAL_BATCH_SIZE);
        next[group.id] = freshBatchIds;

        if (freshBatchIds.join(",") !== storedBatchIds.join(",")) {
          didChange = true;
        }
      });

      if (Object.keys(current).length !== Object.keys(next).length) {
        didChange = true;
      }

      return didChange ? next : current;
    });
  }, [visionDiscoverySummary, excludedImageIdsByVisionGroupId, imageRecordsById]);

  const storyFirstQueue = useMemo(() => {
    return entryViewModels
      .filter(({ entry }) => !entry.reviewed)
      .filter(({ entry }) => {
        const editorialRecommendations = getEntryEditorialRecommendations(entry);
        return (
          editorialRecommendations.some((recommendation) =>
            recommendation.source === "v0.2"
              ? recommendation.recommendation.kind === "story" || recommendation.recommendation.kind === "hero" || recommendation.recommendation.kind === "favorite"
              : recommendation.kind === "story" || recommendation.kind === "hero" || recommendation.kind === "favorite"
          )
        );
      })
      .sort((left, right) => {
        const leftPriority = getQueuePriority(left.entry);
        const rightPriority = getQueuePriority(right.entry);

        if (leftPriority !== rightPriority) {
          return leftPriority - rightPriority;
        }

        return left.index - right.index;
      });
  }, [entryViewModels]);

  const needsConfirmationQueue = useMemo(() => {
    return entryViewModels
      .filter(({ entry }) => !entry.reviewed)
      .filter(({ entry }) => {
        const categories = entry.analysisSuggestions?.categories ?? [];
        return (
          categories.includes("needs-review") ||
          categories.includes("low-confidence") ||
          categories.includes("possible-duplicates")
        );
      })
      .sort((left, right) => left.index - right.index);
  }, [entryViewModels]);

  const firstUnreviewedEntryIndex = useMemo(
    () => importVisit?.entries.findIndex((entry) => !entry.reviewed) ?? -1,
    [importVisit]
  );

  const primaryArchiveAction = useMemo((): { type: PrimaryArchiveAction; label: string; hint: string } => {
    if (!importVisit) {
      return {
        type: "import",
        label: "Import photographs",
        hint: "Start by importing a ZIP archive to create your real archive.",
      };
    }

    if (isVisitFinalized) {
      return {
        type: "publish",
        label: "Download publish-ready output",
        hint: "Your archive review is complete and ready to publish.",
      };
    }

    if (canFinalizePrivacySafe) {
      return {
        type: "finalize",
        label: "Finalize archive review",
        hint: "All entries are reviewed. Finalize before publishing.",
      };
    }

    if (storyFirstQueue.length > 0 && storySelectedEntryCount === 0) {
      return {
        type: "story",
        label: "Review Story recommendations",
        hint: "AI has recommended images with Story potential. Review and curate them.",
      };
    }

    if (storyFirstQueue.length > 0 || needsConfirmationQueue.length > 0) {
      return {
        type: "review-ai",
        label: "Review AI suggestions",
        hint: "AI inbox has items waiting for curator confirmation.",
      };
    }

    return {
      type: "review",
      label: "Continue review",
      hint: "Continue reviewing entries to enrich your archive.",
    };
  }, [
    canFinalizePrivacySafe,
    importVisit,
    isVisitFinalized,
    needsConfirmationQueue.length,
    storyFirstQueue.length,
    storySelectedEntryCount,
  ]);

  useEffect(() => {
    if (!activeBatchFilterId || !importVisit?.importBatches?.some((batch) => batch.id === activeBatchFilterId)) {
      setActiveBatchFilterId(null);
    }
  }, [activeBatchFilterId, importVisit]);

  function handleFinalizeImportedVisit() {
    commitImportVisit((currentVisit) => {
      if (!currentVisit) {
        return currentVisit;
      }

      const reviewedCount = currentVisit.entries.filter((entry) => entry.reviewed).length;
      const totalEntries = currentVisit.entries.length;
      const readyToFinalize = totalEntries > 0 && reviewedCount === totalEntries &&
        currentVisit.entries.every((entry) => !isEntryPrivacyBlocked(entry));

      if (!readyToFinalize) {
        return currentVisit;
      }

      return {
        ...currentVisit,
        status: "Finalized",
      };
    });
  }

  function handleRunStoryAnalysis() {
    commitImportVisit((currentVisit) => currentVisit ? applyStoryRecommendations(currentVisit) : currentVisit);
  }

  async function handleAnalyzeLatestBatch() {
    if (!importVisit || !latestImportBatch || batchVisionProgress?.running) {
      return;
    }

    const entriesByImageRecordId = new Map(
      importVisit.entries.map((entry) => [entry.imageRecordId, entry])
    );

    const targets = (importVisit.imageRecords ?? [])
      .filter((imageRecord) => imageRecord.importBatchId === latestImportBatch.id)
      .map((imageRecord) => ({
        imageRecord,
        entry: entriesByImageRecordId.get(imageRecord.id),
      }))
      .filter(
        (target): target is { imageRecord: ImageRecord; entry: Entry } =>
          Boolean(target.entry) && !target.entry?.visualAnalysis
      );

    setBatchVisionProgress({
      completed: 0,
      total: targets.length,
      failed: 0,
      running: targets.length > 0,
    });

    if (targets.length === 0) {
      return;
    }

    let workingVisit = importVisit;
    let completed = 0;
    let failed = 0;

    for (const { imageRecord, entry } of targets) {
      try {
        const visualAnalysis = await visionProvider.analyzeImage({
          imageRecordId: imageRecord.id,
          filename: imageRecord.filename,
          imageUrl: createThumbnailUrlForRecord(imageRecord),
        });

        workingVisit = {
          ...workingVisit,
          entries: workingVisit.entries.map((currentEntry) =>
            currentEntry.id === entry.id
              ? {
                  ...currentEntry,
                  visualAnalysis,
                  updatedAt: new Date().toISOString(),
                }
              : currentEntry
          ),
        };

        workingVisit = applyStoryRecommendations(workingVisit);
        commitImportVisit(workingVisit);
      } catch (error) {
        failed += 1;
        console.error(`Vision analysis failed for ${imageRecord.filename}`, error);
      }

      completed += 1;

      setBatchVisionProgress({
        completed,
        total: targets.length,
        failed,
        running: completed < targets.length,
      });
    }
  }

  function openReviewWithIndex(index: number) {
    setReviewStartIndex(index);
    setIsReviewingEntries(true);
  }

  function openReviewForImageRecord(imageRecordId: string, visionGroupId?: string) {
    if (!importVisit) {
      return;
    }

    const index = importVisit.entries.findIndex((entry) => entry.imageRecordId === imageRecordId);
    if (index < 0) {
      return;
    }

    if (visionGroupId) {
      setActiveVisionGroupId(visionGroupId);
    }

    openReviewWithIndex(index);
  }

  function handleCloseEntryReview() {
    setIsReviewingEntries(false);

    if (!activeVisionGroupId) {
      return;
    }

    const groupElement = document.querySelector(`[data-testid="vision-group-card-${activeVisionGroupId}"]`) as HTMLElement | null;
    const fallbackTarget = visionSummaryRef.current;
    const target = groupElement ?? fallbackTarget;

    if (target) {
      requestAnimationFrame(() => {
        target.scrollIntoView({ behavior: "auto", block: "center" });
      });
    }

    setActiveVisionGroupId(null);
  }

  function startReviewQueue(mode: ReviewQueueMode) {
    const queue = mode === "story-first" ? storyFirstQueue : needsConfirmationQueue;
    if (queue.length === 0) {
      return;
    }

    openReviewWithIndex(queue[0].index);
  }

  function triggerImportFromSidebar() {
    sidebarImportSectionRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
    const importInput = document.getElementById("zip-import-input") as HTMLInputElement | null;
    importInput?.click();
  }

  function handlePrimaryArchiveAction() {
    switch (primaryArchiveAction.type) {
      case "import":
        triggerImportFromSidebar();
        return;
      case "publish":
        handleDownloadPublishReadyOutput();
        return;
      case "finalize":
        handleFinalizeImportedVisit();
        return;
      case "story":
        startReviewQueue("story-first");
        return;
      case "review-ai":
        if (storyFirstQueue.length > 0) {
          startReviewQueue("story-first");
          return;
        }

        startReviewQueue("needs-confirmation");
        return;
      case "review":
      default:
        if (firstUnreviewedEntryIndex >= 0) {
          openReviewWithIndex(firstUnreviewedEntryIndex);
          return;
        }

        openReviewWithIndex(0);
    }
  }

  function handleDownloadPublishReadyOutput() {
    if (!importVisit || !isVisitFinalized || importVisit.entries.some((entry) => isEntryPrivacyBlocked(entry))) {
      return;
    }

    const output = createPublishReadyVisitOutput(importVisit);
    const outputBlob = new Blob([JSON.stringify(output, null, 2)], { type: "application/json" });
    const outputUrl = URL.createObjectURL(outputBlob);
    const outputLink = document.createElement("a");
    const sanitizedDate = importVisit.date.replace(/[^0-9-]/g, "-");

    outputLink.href = outputUrl;
    outputLink.download = `visit-${sanitizedDate}-publish-ready.json`;
    document.body.appendChild(outputLink);
    outputLink.click();
    document.body.removeChild(outputLink);
    URL.revokeObjectURL(outputUrl);
  }

  function handleVisionGroupPlaceSelection(groupId: string, placeId: string) {
    setSelectedPlaceByVisionGroupId((currentSelections) => ({
      ...currentSelections,
      [groupId]: placeId,
    }));
  }

  function handleExcludeImageFromVisionGroup(groupId: string, imageRecordId: string) {
    setExcludedImageIdsByVisionGroupId((current) => ({
      ...current,
      [groupId]: Array.from(new Set([...(current[groupId] ?? []), imageRecordId])),
    }));
  }

  function handleApproveVisionGroupPlace(group: VisionPlaceCandidateGroup) {
    if (!importVisit) {
      return;
    }

    const selectedCanonicalPlaceId = selectedPlaceByVisionGroupId[group.id];
    if (!selectedCanonicalPlaceId) {
      return;
    }

    const canonicalPlace = getPlaceById(selectedCanonicalPlaceId);
    if (!canonicalPlace) {
      setPlaceAssignmentFeedback("Select a valid canonical place before approving.");
      return;
    }

    const excludedImageIds = new Set(excludedImageIdsByVisionGroupId[group.id] ?? []);
    const { batchImageRecordIds } = getVisionReviewBatch(group);
    const batchImageRecordIdSet = new Set(batchImageRecordIds);
    const correctedGroup: VisionPlaceCandidateGroup = {
      ...group,
      // Approval must only ever touch the currently visible, reviewed batch —
      // never a hidden or not-yet-reviewed photograph from the wider cluster.
      imageRecordIds: group.imageRecordIds.filter(
        (id) => batchImageRecordIdSet.has(id) && !excludedImageIds.has(id)
      ),
      entryIds: group.entryIds.filter((entryId) => {
        const entry = importVisit.entries.find((candidate) => candidate.id === entryId);
        return entry ? batchImageRecordIdSet.has(entry.imageRecordId) && !excludedImageIds.has(entry.imageRecordId) : false;
      }),
    };

    const assignment = assignCanonicalPlaceToVisionGroup({
      visit: importVisit,
      group: correctedGroup,
      canonicalPlaceId: canonicalPlace.id,
    });

    if (assignment.assignedCount === 0) {
      setPlaceAssignmentFeedback("No unassigned photographs were available in this group.");
      return;
    }

    commitImportVisit(assignment.visit);
    setPlaceAssignmentFeedback(
      `Assigned ${canonicalPlace.displayName} to ${assignment.assignedCount} photographs.`
    );
    // Reset the canonical-place choice so it never carries forward into the next review batch.
    setSelectedPlaceByVisionGroupId((currentSelections) => {
      const { [group.id]: _removed, ...rest } = currentSelections;
      return rest;
    });
  }

  function handleExportArchiveBackup() {
    if (!hasExportableArchive) {
      return;
    }

    const backup = createArchiveStateSnapshot({ importVisit, draftWorkspace });
    const backupBlob = new Blob([JSON.stringify(backup, null, 2)], { type: "application/json" });
    const backupUrl = URL.createObjectURL(backupBlob);
    const backupLink = document.createElement("a");

    backupLink.href = backupUrl;
    backupLink.download = `blomzip-archive-backup-${backup.savedAt.slice(0, 10)}.json`;
    document.body.appendChild(backupLink);
    backupLink.click();
    document.body.removeChild(backupLink);
    URL.revokeObjectURL(backupUrl);
  }

  function getImageFilename(image: ImageItem, imageRecord?: Pick<ImageRecord, "filename"> | null) {
    return getGalleryCardDisplayTitle(image, imageRecord);
  }

  function renderMeta(label: string, value: string) {
    if (!value) {
      return null;
    }

    return (
      <p>
        <strong>{label}:</strong> {value}
      </p>
    );
  }

  function getVisionActionablePoolIds(group: VisionPlaceCandidateGroup): string[] {
    const excludedImageIds = new Set(excludedImageIdsByVisionGroupId[group.id] ?? []);

    return group.imageRecordIds.filter((recordId) => {
      if (excludedImageIds.has(recordId)) {
        return false;
      }

      const record = imageRecordsById.get(recordId);
      return Boolean(record && !record.placeId);
    });
  }

  function getVisionReviewBatch(group: VisionPlaceCandidateGroup): {
    representativeRecord: ImageRecord | undefined;
    representativeLabel: string;
    memberRecords: ImageRecord[];
    batchImageRecordIds: string[];
    actionablePoolSize: number;
    remainingAfterBatchCount: number;
  } {
    const actionablePoolIds = getVisionActionablePoolIds(group);
    const actionablePoolIdSet = new Set(actionablePoolIds);

    const storedBatchIds = reviewBatchByVisionGroupId[group.id] ?? [];
    const activeStoredBatchIds = storedBatchIds.filter((recordId) => actionablePoolIdSet.has(recordId));

    // Never backfill an unseen photograph into an already-visible, partially
    // reviewed batch; only start a fresh batch once the current one resolves.
    const batchImageRecordIds = activeStoredBatchIds.length > 0
      ? activeStoredBatchIds
      : actionablePoolIds.slice(0, MAX_PLACE_APPROVAL_BATCH_SIZE);

    const batchRecords = batchImageRecordIds
      .map((recordId) => imageRecordsById.get(recordId))
      .filter((record): record is ImageRecord => Boolean(record));

    // Keep the cluster's chosen representative when it's still part of the
    // current batch; only fall back to the first batch member once it's gone.
    const representativeId = batchImageRecordIds.includes(group.representativeImageRecordId)
      ? group.representativeImageRecordId
      : batchImageRecordIds[0];
    const representativeRecord = representativeId ? imageRecordsById.get(representativeId) : undefined;
    const representativeLabel = representativeRecord?.filename ?? group.representativeImageRecordId;
    const memberRecords = batchRecords.filter((record) => record.id !== representativeId);

    return {
      representativeRecord,
      representativeLabel,
      memberRecords,
      batchImageRecordIds,
      actionablePoolSize: actionablePoolIds.length,
      remainingAfterBatchCount: Math.max(0, actionablePoolIds.length - batchRecords.length),
    };
  }

  function renderGalleryCard({ image, index }: { image: ImageItem; index: number }) {
    const entry = importVisit?.entries[index];
    const imageRecord = entry ? imageRecordsById.get(entry.imageRecordId) : undefined;
    const reviewed = entry?.reviewed;
    const displayTitle = getImageFilename(image, imageRecord);
    const thumbnailSrc = resolveGalleryThumbnailSrc(image, imageRecord);
    const suggestionCategories = entry?.analysisSuggestions?.categories ?? [];
    const captureLabel = importVisit ? formatDateLabel(imageRecord?.captureDate) : "Demo image";
    const prioritizedSuggestionCategories: EntrySuggestionCategory[] = [
      "story-candidate",
      "hero-candidate",
      "favorite-candidate",
      "strong-change",
      "overview-image",
      "detail-image",
      "by-place",
      "needs-review",
      "low-confidence",
      "possible-duplicates",
    ];
    const v02Recommendations = entry?.analysisSuggestions?.recommendations;
    const editorialRecommendations = entry ? getEntryEditorialRecommendations(entry) : [];
    const authoritativeRecommendations = v02Recommendations !== undefined
      ? editorialRecommendations
      : [];
    const legacySuggestionCategories = v02Recommendations === undefined
      ? prioritizedSuggestionCategories.filter((category) => suggestionCategories.includes(category))
      : [];
    const primaryV02Recommendation = authoritativeRecommendations[0];
    const primarySuggestionCategory = legacySuggestionCategories[0];
    const additionalSuggestionCount = Math.max(
      (primaryV02Recommendation ? authoritativeRecommendations.length : legacySuggestionCategories.length) - 1,
      0
    );
    const placeLabel = importVisit
      ? imageRecord?.placeId
        ? getPlaceById(imageRecord.placeId)?.displayName ?? "Unknown"
        : "Unknown"
      : image.location;

    return (
      <article
        key={image.id}
        className={`gallery-card ${activeGalleryImageId === image.id ? "is-current" : ""}`}
      >
        <button
          type="button"
          className="gallery-card-button preview-card-button"
          onClick={() => (importVisit ? openReviewWithIndex(index) : setSelectedImage(image))}
          aria-label={`Open ${displayTitle}`}
          aria-pressed={activeGalleryImageId === image.id}
        >
          <div className="gallery-card-thumb">
            {thumbnailSrc ? <img src={thumbnailSrc} alt={image.alt} /> : <span>No preview</span>}
          </div>

          <div className="gallery-card-body">
            <div className="gallery-card-header">
              <strong>{displayTitle}</strong>
              <span>Review · #{index + 1}</span>
            </div>

            <p className="gallery-card-meta">
              {captureLabel}
              {!importVisit ? (
                <>
                  <span>•</span>
                  Demo collection
                </>
              ) : (
                <>
                  <span>•</span>
                  {placeLabel}
                </>
              )}
            </p>

            <div className="gallery-card-signals">
              {reviewed !== undefined ? (
                <span
                  className={`gallery-card-workflow ${reviewed ? "reviewed" : "pending"}`}
                  data-testid={`gallery-workflow-${entry?.id ?? image.id}`}
                >
                  {reviewed ? "Reviewed" : "Pending"}
                </span>
              ) : null}

              {(image.favorite || image.hero || entry?.storySelected) ? (
                <div className="gallery-card-curation" data-testid={`gallery-curation-${entry?.id ?? image.id}`} aria-label="Curator selections">
                  {image.favorite ? <span className="gallery-card-curation-chip">Favorite</span> : null}
                  {image.hero ? <span className="gallery-card-curation-chip">Hero</span> : null}
                  {entry?.storySelected ? <span className="gallery-card-curation-chip">Story</span> : null}
                </div>
              ) : null}

              {primaryV02Recommendation?.source === "v0.2" ? (
                <div className="gallery-card-recommendation" data-testid={`gallery-ai-recommendation-${entry?.id ?? image.id}`}>
                  <span className="gallery-card-ai-chip">AI · {primaryV02Recommendation.recommendation.kind.charAt(0).toUpperCase()}{primaryV02Recommendation.recommendation.kind.slice(1)}</span>
                  {additionalSuggestionCount > 0 ? (
                    <span className="gallery-card-ai-count" title={`${additionalSuggestionCount} additional AI recommendations`}>
                      +{additionalSuggestionCount} AI
                    </span>
                  ) : null}
                </div>
              ) : primarySuggestionCategory ? (
                <div className="gallery-card-recommendation" data-testid={`gallery-ai-recommendation-${entry?.id ?? image.id}`}>
                  <span className="gallery-card-ai-chip">{getSuggestionChipLabel(primarySuggestionCategory)}</span>
                  {additionalSuggestionCount > 0 ? (
                    <span className="gallery-card-ai-count" title={`${additionalSuggestionCount} additional AI recommendations`}>
                      +{additionalSuggestionCount} AI
                    </span>
                  ) : null}
                </div>
              ) : null}
            </div>
          </div>
        </button>

        {entry ? (
          <div className="gallery-card-action-row">
            <button
              type="button"
              className="gallery-card-story-toggle"
              onClick={() => handleStorySelectionFromOverview(index)}
              aria-pressed={Boolean(entry.storySelected)}
            >
              {entry.storySelected ? "Remove from Story" : "Select for Story"}
            </button>
          </div>
        ) : null}
      </article>
    );
  }

  const handleImportStateChange = useCallback(
    async ({
      summary,
      visit,
    }: {
      summary: ZipImportSummary | null;
      visit: Visit | null;
    }): Promise<BatchImportOutcome | void> => {
      setImportSummary(summary);
      if (!visit) {
        return;
      }

      const incomingBatchId = visit.importBatches?.[0]?.id ?? null;
      const mergedVisit = mergeImportedVisit(latestImportVisitRef.current, visit, {
        observationEngine: overviewObservationEngine,
      });

      if (!mergedVisit) {
        return;
      }

      commitImportVisit(mergedVisit);
      setLatestImportedBatchIdForVision(incomingBatchId);
      setBatchVisionProgress(null);

      const outcome = createBatchImportOutcome(mergedVisit, incomingBatchId);
      if (outcome) {
        setLastBatchImportFeedback(outcome);
        return outcome;
      }
    },
    [overviewObservationEngine]
  );

  const hasLegacyUnhashedRecords = useMemo(() => {
    return (importVisit?.imageRecords ?? []).some((record) => !record.contentHash);
  }, [importVisit]);

  return (
    <main className={`studio ${isEntryReviewMode ? "review-mode" : ""}`}>
      <aside className="sidebar">
        {isEntryReviewMode ? (
          <>
            <section className="sidebar-card sidebar-review-focus-card" data-testid="sidebar-review-focus-section">
              <div>
                <p className="eyebrow">Archive context</p>
                <h3>Current review session</h3>
              </div>

              <div className="archive-overview-grid compact">
                <div>
                  <span>Photographs</span>
                  <strong>{archiveStats.totalPhotographs}</strong>
                </div>
                <div>
                  <span>Batches</span>
                  <strong>{archiveStats.importBatchCount}</strong>
                </div>
                <div>
                  <span>Review progress</span>
                  <strong>{reviewedEntryCount}/{totalImportedEntries}</strong>
                </div>
                <div>
                  <span>Story selected</span>
                  <strong>{archiveStats.storySelected}</strong>
                </div>
              </div>
            </section>

            {latestImportBatch ? (
              <section className="sidebar-card sidebar-review-focus-card" data-testid="sidebar-review-batch-section">
                <div>
                  <p className="eyebrow">Batch provenance</p>
                  <h3>{latestImportBatch.fileName}</h3>
                  <p className="result-count">Imported {formatDateLabel(latestImportBatch.importedAt)}</p>
                  <p className="result-count">
                    {formatBatchImportSummary(
                      latestImportBatch.rawImageCount ?? latestImportBatch.imageCount,
                      latestImportBatch.importedImageCount ?? latestImportBatch.imageCount,
                      latestImportBatch.duplicateSkippedCount ?? 0
                    )}
                  </p>
                </div>
              </section>
            ) : null}

            <section className="sidebar-card sidebar-save-load-card" data-testid="sidebar-drafts-section">
              <div>
                <p className="eyebrow">Draft workspace</p>
                <h3>Save progress</h3>
              </div>

              <div className="collection-stats draft-actions">
                <button type="button" className="secondary-action" onClick={handleSaveDraft} disabled={!importVisit}>
                  Save Draft
                </button>
                <button type="button" className="secondary-action" onClick={handleExportArchiveBackup} disabled={!hasExportableArchive}>
                  Export archive backup
                </button>
              </div>
            </section>
          </>
        ) : (
          <>
            <section className={`sidebar-import-shell ${importVisit ? "secondary" : "primary"}`} ref={sidebarImportSectionRef} data-testid="sidebar-import-section">
              <ZipImportPanel
                className="zip-panel"
                onImportStateChange={handleImportStateChange}
              />

              {importSummary ? (
                <div className="sidebar-card import-summary-mini">
                  <span>ZIP ready</span>
                  <strong className="import-summary-mini-filename" title={importSummary.fileName}>
                    {importSummary.fileName}
                  </strong>
                  <p className="result-count">
                    {importSummary.imageCount} supported images found, {importSummary.status}
                  </p>
                </div>
              ) : null}

              {hasLegacyUnhashedRecords ? (
                <p className="result-count">
                  Legacy photographs do not have exact fingerprints and cannot be matched automatically. Duplicate protection applies between imports made after this update.
                </p>
              ) : null}
            </section>

            {batchOverview.length > 0 ? (
              <section className="sidebar-card archive-batches-card" data-testid="sidebar-batches-section">
                <div className="archive-batches-header">
                  <button
                    type="button"
                    className="archive-batches-toggle"
                    onClick={handleToggleBatchProvenance}
                    aria-expanded={isBatchProvenanceSectionExpanded}
                    aria-controls="sidebar-batch-list"
                    data-testid="sidebar-batches-toggle"
                  >
                    <span className="archive-batches-toggle-label">
                      <p className="eyebrow">Import batches</p>
                      <h3>Batch provenance ({batchOverview.length})</h3>
                    </span>
                    <span className="archive-batches-toggle-state" aria-hidden="true">
                      {isBatchProvenanceSectionExpanded ? "Hide" : "Show"}
                    </span>
                  </button>
                  {activeBatchFilterId ? (
                    <button type="button" className="secondary-action" onClick={() => setActiveBatchFilterId(null)}>
                      Clear filter
                    </button>
                  ) : null}
                </div>

                {isBatchProvenanceSectionExpanded ? (
                  <div className="batch-list" id="sidebar-batch-list" data-testid="sidebar-batch-list">
                    {batchOverview.map(({ batch, captureRange, reviewedCount, totalCount, reviewPercent }) => (
                      <button
                        key={batch.id}
                        type="button"
                        className={`batch-item ${activeBatchFilterId === batch.id ? "active" : ""}`}
                        onClick={() => setActiveBatchFilterId((current) => (current === batch.id ? null : batch.id))}
                        aria-pressed={activeBatchFilterId === batch.id}
                      >
                        <div className="batch-item-header">
                          <span className="batch-item-filename" title={batch.fileName}>
                            {batch.fileName}
                          </span>
                          <span className="batch-item-count">{batch.importedImageCount ?? batch.imageCount} added</span>
                        </div>
                        <p>Imported {formatDateLabel(batch.importedAt)}</p>
                        <p>
                          {formatBatchImportSummary(
                            batch.rawImageCount ?? batch.imageCount,
                            batch.importedImageCount ?? batch.imageCount,
                            batch.duplicateSkippedCount ?? 0
                          )}
                        </p>
                        <p>Capture range: {captureRange}</p>
                        {totalCount > 0 ? (
                          <p>
                            Review progress: {reviewedCount}/{totalCount} ({reviewPercent}%)
                          </p>
                        ) : (
                          <p>No new photographs to review</p>
                        )}
                      </button>
                    ))}
                  </div>
                ) : null}
              </section>
            ) : null}

            <section className="sidebar-card sidebar-save-load-card" data-testid="sidebar-drafts-section">
              <div>
                <p className="eyebrow">Draft workspace</p>
                <h3>Save or load a draft</h3>
                <p className="result-count">
                  Keep the current curation session in browser storage without changing the canonical archive.
                </p>
              </div>

              <div className="collection-stats draft-actions">
                <button type="button" className="secondary-action" onClick={handleSaveDraft} disabled={!importVisit}>
                  Save Draft
                </button>

                <button type="button" className="secondary-action" onClick={handleExportArchiveBackup} disabled={!hasExportableArchive}>
                  Export archive backup
                </button>

                {savedDrafts.length > 0 ? (
                  savedDrafts.map((draftVisit) => (
                    <button
                      key={draftVisit.id}
                      type="button"
                      className={draftWorkspace.activeDraftId === draftVisit.id ? "active" : ""}
                      onClick={() => handleLoadDraft(draftVisit)}
                    >
                      <span>{draftVisit.label}</span>
                      <strong>{draftVisit.visit.entries.length} entries</strong>
                    </button>
                  ))
                ) : (
                  <p className="result-count">No saved drafts yet.</p>
                )}
              </div>
            </section>
          </>
        )}
      </aside>

      <section className="content">
        {isReviewingEntries && importVisit ? (
          <EntryReview
            visit={importVisit}
            initialEntryIndex={reviewStartIndex}
            onClose={handleCloseEntryReview}
            onEntryUpdated={handleImportEntryUpdated}
            onVisitFinalized={handleVisitFinalized}
            onImageRecordPlaceChanged={handleEntryReviewImageRecordPlaceChanged}
          />
        ) : (
          <div className="gallery-shell">
            <section className="archive-home-summary" data-testid="archive-home-summary">
              <div>
                <p className="eyebrow">{importVisit ? "Archive home" : "Demo mode"}</p>
                <h2>{importVisit ? "Current archive" : "Current archive not loaded"}</h2>
                <p className="result-count">
                  {importVisit
                    ? `${archiveStats.totalPhotographs} photographs across ${archiveStats.importBatchCount} import batches.`
                    : "Demo collection preview is visible and not part of your archive."}
                </p>
              </div>

              <div className="archive-home-stats">
                <div>
                  <span>Total photographs</span>
                  <strong>{archiveStats.totalPhotographs}</strong>
                </div>
                <div>
                  <span>Import batches</span>
                  <strong>{archiveStats.importBatchCount}</strong>
                </div>
                <div>
                  <span>Date range</span>
                  <strong>{archiveDateRange}</strong>
                </div>
                <div>
                  <span>Story selected</span>
                  <strong>{archiveStats.storySelected}</strong>
                </div>
                <div>
                  <span>Review progress</span>
                  <strong>{totalImportedEntries > 0 ? `${reviewedEntryCount}/${totalImportedEntries}` : "No archive entries"}</strong>
                </div>
              </div>
            </section>

            <nav className="studio-workflow" aria-label="Studio workflow" data-testid="studio-workflow">
              <span>Import images</span>
              <span aria-hidden="true">→</span>
              <span>Place Discovery</span>
              <span aria-hidden="true">→</span>
              <span>Image Analysis</span>
              <span aria-hidden="true">→</span>
              <span>Editorial Recommendations</span>
              <span aria-hidden="true">→</span>
              <span>Review &amp; Curate</span>
            </nav>

            <LivingMapPanel selectedPlaceId={archivePlaceFilter} onPlaceSelect={setArchivePlaceFilter} />

            <section className="archive-attention-card" data-testid="archive-next-action">
              <div>
                <p className="eyebrow">Next useful action</p>
                <h3>{primaryArchiveAction.label}</h3>
                <p className="result-count">{primaryArchiveAction.hint}</p>
              </div>

              {visionDiscoverySummary ? (
                <section className="vision-engine-summary" data-testid="vision-engine-summary" aria-live="polite" ref={visionSummaryRef}>
                  <div className="vision-engine-summary-header">
                    <p className="eyebrow">Place Discovery</p>
                    <p className="result-count">
                      {visionDiscoverySummary.analyzedImageCount} images processed for place discovery
                      {visionDiscoverySummary.analysisScope === "import-batch" ? " (latest import)" : " (full archive)"}
                    </p>
                  </div>

                  <p className="result-count">
                    {visionDiscoverySummary.candidatePlaceGroupCount} candidate place groups
                  </p>

                  {visionDiscoverySummary.candidatePlaceGroups.length > 0 ? (
                    <div className="vision-engine-groups">
                      {visionDiscoverySummary.candidatePlaceGroups.map((group) => {
                        const {
                          representativeRecord,
                          representativeLabel,
                          memberRecords,
                          actionablePoolSize,
                          remainingAfterBatchCount,
                        } = getVisionReviewBatch(group);
                        const batchSize = memberRecords.length + (representativeRecord ? 1 : 0);
                        const representativeThumbnailSrc = createThumbnailUrlForRecord(representativeRecord);
                        const selectedPlaceId = selectedPlaceByVisionGroupId[group.id] ?? "";

                        return (
                          <article key={group.id} className="vision-engine-group-item" data-testid={`vision-group-card-${group.id}`}>
                            <div className="vision-engine-group-image-column">
                              <div className="vision-engine-group-representative-wrapper">
                                <button
                                  type="button"
                                  className="vision-engine-group-image-button vision-engine-group-representative"
                                  data-testid={`vision-group-representative-${group.id}`}
                                  onClick={() => representativeRecord ? openReviewForImageRecord(representativeRecord.id, group.id) : undefined}
                                  disabled={!representativeRecord}
                                  aria-label={`Open representative ${representativeLabel}`}
                                >
                                  {representativeThumbnailSrc ? (
                                    <img src={representativeThumbnailSrc} alt={representativeLabel} data-object-fit="contain" />
                                  ) : (
                                    <span>No preview</span>
                                  )}
                                </button>

                                {representativeRecord ? (
                                  <button
                                    type="button"
                                    className="vision-engine-group-remove-image vision-engine-group-remove-representative"
                                    onClick={() => handleExcludeImageFromVisionGroup(group.id, representativeRecord.id)}
                                    aria-label={`Remove ${representativeLabel} from this place group`}
                                    title="Remove from group"
                                  >
                                    ×
                                  </button>
                                ) : null}
                              </div>
                              <div className="vision-engine-group-preview-strip" data-testid={`vision-group-preview-strip-${group.id}`}>
                                {memberRecords.map((record) => {
                                  const previewSrc = createThumbnailUrlForRecord(record);

                                  return (
                                    <div
                                      key={record.id}
                                      className="vision-engine-group-preview-wrapper"
                                    >
                                      <button
                                        type="button"
                                        className="vision-engine-group-image-button vision-engine-group-preview-button"
                                        data-testid={`vision-group-preview-${group.id}-${record.id}`}
                                        onClick={() => openReviewForImageRecord(record.id, group.id)}
                                        aria-label={`Open ${record.filename}`}
                                      >
                                        {previewSrc ? (
                                          <img
                                            src={previewSrc}
                                            alt={record.filename}
                                            data-object-fit="contain"
                                          />
                                        ) : (
                                          <span>No preview</span>
                                        )}
                                      </button>

                                      <button
                                        type="button"
                                        className="vision-engine-group-remove-image"
                                        onClick={() => handleExcludeImageFromVisionGroup(group.id, record.id)}
                                        aria-label={`Remove ${record.filename} from this place group`}
                                        title="Remove from group"
                                      >
                                        ×
                                      </button>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>

                            <div className="vision-engine-group-details-column">
                              <div className="vision-engine-group-primary-metadata">
                                <strong>{group.imageRecordIds.length} photographs</strong>
                                <div>
                                  <span>Confidence</span>
                                  <strong>{formatPercent(group.confidence)}</strong>
                                </div>
                              </div>

                              <p
                                className="result-count vision-engine-group-batch-progress"
                                data-testid={`vision-group-batch-progress-${group.id}`}
                              >
                                Reviewing {batchSize} of {actionablePoolSize} · {remainingAfterBatchCount} remaining
                              </p>

                              <label className="vision-engine-group-assign-label" htmlFor={`vision-place-select-${group.id}`}>
                                Canonical place
                              </label>
                              <div className="vision-engine-group-assign-row">
                                <div className="vision-engine-group-assign-select-column">
                                  <select
                                    id={`vision-place-select-${group.id}`}
                                    data-testid={`vision-place-select-${group.id}`}
                                    value={selectedPlaceId}
                                    onChange={(event) => handleVisionGroupPlaceSelection(group.id, event.target.value)}
                                  >
                                    <option value="">Select place...</option>
                                    {canonicalPlaces.map((place) => (
                                      <option key={place.id} value={place.id}>
                                        {place.displayName}
                                      </option>
                                    ))}
                                  </select>
                                </div>
                                {selectedPlaceId && (
                                  <button
                                    type="button"
                                    className="place-map-toggle"
                                    onClick={() => setOpenPlaceMapGroupId(openPlaceMapGroupId === group.id ? null : group.id)}
                                    data-testid={`vision-place-map-toggle-${group.id}`}
                                    title="Show place map reference"
                                  >
                                    {openPlaceMapGroupId === group.id ? "Hide map" : "Show map"}
                                  </button>
                                )}
                              </div>
                              {batchSize > 0 ? (
                                <button
                                  type="button"
                                  className="secondary-action vision-engine-group-approve"
                                  data-testid={`vision-place-approve-${group.id}`}
                                  onClick={() => handleApproveVisionGroupPlace(group)}
                                  disabled={!selectedPlaceId}
                                >
                                  Approve place for {batchSize} photographs
                                </button>
                              ) : (
                                <p
                                  className="vision-engine-group-approval-resolved"
                                  data-testid={`vision-place-approval-resolved-${group.id}`}
                                >
                                  Already assigned
                                </p>
                              )}

                              {openPlaceMapGroupId === group.id && selectedPlaceId && (
                                <div className="place-map-overlay" onClick={() => setOpenPlaceMapGroupId(null)}>
                                  <div
                                    className="place-map-popover"
                                    onClick={(e) => e.stopPropagation()}
                                  >
                                    <PlaceMapReference
                                      selectedPlaceId={selectedPlaceId}
                                      onClose={() => setOpenPlaceMapGroupId(null)}
                                    />
                                  </div>
                                </div>
                              )}

                              <p className="result-count vision-engine-group-representative-label">Representative: {representativeLabel}</p>
                            </div>
                          </article>
                        );
                      })}
                    </div>
                  ) : null}

                  {placeAssignmentFeedback ? (
                    <p className="result-count" aria-live="polite">{placeAssignmentFeedback}</p>
                  ) : null}
                </section>
              ) : null}

              {importVisit ? (
                <section className="story-analysis-summary" data-testid="story-analysis-summary" aria-live="polite">
                  <div>
                    <p className="eyebrow">Image Analysis</p>
                    <h4>Editorial Recommendations</h4>
                    <p className="result-count">{storyAnalysisSummary.assessedPhotographCount} analyzed images</p>
                    <p className="result-count">{storyAnalysisSummary.recommendationCount} Story recommendations</p>

                    {storyFirstQueue.length > 0 ? (
                      <div className="story-recommendation-previews" data-testid="story-recommendation-previews">
                        {storyFirstQueue.slice(0, 3).map(({ entry, imageRecord, filename, index }) => {
                          const storyRecommendation = entry.analysisSuggestions?.recommendations?.find(
                            (recommendation) => recommendation.kind === "story"
                          );
                          const heroRecommendation = entry.analysisSuggestions?.recommendations?.find(
                            (recommendation) => recommendation.kind === "hero"
                          );
                          const thumbnailSrc = createThumbnailUrlForRecord(imageRecord);
                          const explanation = storyRecommendation?.reasons?.[0];

                          return (
                            <button
                              key={entry.id}
                              type="button"
                              className={`story-recommendation-preview${heroRecommendation ? " is-hero-recommendation" : ""}`}
                              onClick={() => openReviewWithIndex(index)}
                            >
                              <span className="story-recommendation-image">
                                {thumbnailSrc ? <img src={thumbnailSrc} alt={filename} /> : <span>No preview</span>}
                                {heroRecommendation ? <span className="hero-recommendation-badge">Hero</span> : null}
                              </span>
                              <span className="story-recommendation-copy">
                                <strong>{filename}</strong>
                                {explanation ? <small>{explanation}</small> : null}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    ) : null}
                  </div>
                  <div>
                    <button
                      type="button"
                      className="secondary-action story-analysis-run"
                      data-testid="analyze-latest-batch"
                      onClick={() => void handleAnalyzeLatestBatch()}
                      disabled={batchVisionProgress?.running}
                    >
                      {batchVisionProgress?.running
                        ? `Analyzing ${batchVisionProgress.completed} / ${batchVisionProgress.total}`
                        : "Analyze new images"}
                    </button>

                    {batchVisionProgress && !batchVisionProgress.running ? (
                      <p className="result-count" data-testid="batch-vision-result">
                        {batchVisionProgress.total === 0
                          ? "All new images analyzed"
                          : `${batchVisionProgress.completed - batchVisionProgress.failed} images analyzed${
                              batchVisionProgress.failed > 0
                                ? ` · ${batchVisionProgress.failed} failed`
                                : ""
                            }`}
                      </p>
                    ) : null}

                    <button
                      type="button"
                      className="secondary-action story-analysis-run"
                      data-testid="run-story-analysis"
                      onClick={handleRunStoryAnalysis}
                    >
                      Update Story recommendations
                    </button>
                  </div>
                </section>
              ) : null}

              <button type="button" className="primary-action" onClick={handlePrimaryArchiveAction} data-testid="primary-next-action">
                {primaryArchiveAction.label}
              </button>

              {lastBatchImportFeedback ? (
                <div className="import-feedback-inline" aria-live="polite">
                  <p className="result-count">✓ {lastBatchImportFeedback.fileName} imported</p>
                  <p className="result-count">
                    {formatBatchImportSummary(
                      lastBatchImportFeedback.rawImageCount,
                      lastBatchImportFeedback.importedImageCount,
                      lastBatchImportFeedback.duplicateSkippedCount
                    )}
                  </p>
                  <p className="result-count">
                    Archive now contains {lastBatchImportFeedback.totalPhotographs} photographs in {lastBatchImportFeedback.totalBatches} batches.
                  </p>
                </div>
              ) : null}

              {importVisit ? (
                <>
                  <div className="review-queue-controls inline">
                    <button
                      type="button"
                      className="secondary-action"
                      onClick={() => startReviewQueue("story-first")}
                      disabled={storyFirstQueue.length === 0}
                    >
                      Story-first queue ({storyFirstQueue.length})
                    </button>
                    <button
                      type="button"
                      className="secondary-action"
                      onClick={() => startReviewQueue("needs-confirmation")}
                      disabled={needsConfirmationQueue.length === 0}
                    >
                      Needs confirmation ({needsConfirmationQueue.length})
                    </button>
                  </div>

                  {aiInboxGroups.length > 0 ? (
                    <div className="ai-inbox-groups inline" data-testid="ai-inbox-main">
                      {aiInboxGroups.map((group) => (
                        <div key={group.key} className="ai-group">
                          <div className="ai-group-header">
                            <strong>{group.title}</strong>
                            <span>{group.items.length}</span>
                          </div>

                          <div className="ai-group-items">
                            {group.items.slice(0, 3).map((item) => {
                              const entry = importVisit.entries[item.index];
                              const topCategory = entry?.analysisSuggestions?.categories?.[0];

                              return (
                                <button
                                  key={item.entryId}
                                  type="button"
                                  className="ai-suggestion-item"
                                  onClick={() => openReviewWithIndex(item.index)}
                                >
                                  <span>{item.filename}</span>
                                  <small>
                                    {topCategory ? mapSuggestionCategoryLabel(topCategory) : "suggestion"}
                                    {typeof item.confidence === "number" ? ` • ${Math.round(item.confidence * 100)}%` : ""}
                                  </small>
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : null}
                </>
              ) : (
                <p className="result-count" data-testid="demo-collection-label">Demo collection preview (not part of your archive).</p>
              )}

              {activeBatchFilterId ? <p className="result-count">Batch filter is active.</p> : null}
            </section>

            <div className="gallery-toolbar">
              <input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search filenames, location, collection, tags or notes..."
              />

              <select value={collectionFilter} onChange={(event) => setCollectionFilter(event.target.value)}>
                {collections.map((collection) => (
                  <option key={collection} value={collection}>
                    {collection}
                  </option>
                ))}
              </select>

              <select
                value={suggestionFilter}
                onChange={(event) => setSuggestionFilter(event.target.value as SuggestionFilter)}
                aria-label="AI suggestion category filter"
                disabled={!importVisit}
              >
                {SUGGESTION_FILTER_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>

              <div className="filter-row filter-row-compact" aria-label="Image view filters">
                <button type="button" className={viewFilter === "all" ? "active" : ""} onClick={() => setViewFilter("all")}>
                  All
                </button>

                <button
                  type="button"
                  className={viewFilter === "favorites" ? "active" : ""}
                  onClick={() => setViewFilter("favorites")}
                >
                  Favorites
                </button>

                <button type="button" className={viewFilter === "hero" ? "active" : ""} onClick={() => setViewFilter("hero")}>
                  Hero
                </button>
              </div>
            </div>

            <section className="gallery-grid">
              {timelineItems.map((timelineItem, timelineIndex) => {
                if (timelineItem.type === "header") {
                  return (
                    <div key={`header-${timelineItem.dateKey}-${timelineIndex}`} className="timeline-date-header" role="heading" aria-level={3}>
                      <span>{timelineItem.label}</span>
                    </div>
                  );
                }

                return renderGalleryCard(timelineItem.item);
              })}
            </section>
          </div>
        )}
      </section>

      {selectedImage && (
        <div className="detail-overlay" onClick={() => setSelectedImage(null)}>
          <article className="detail-panel" onClick={(event) => event.stopPropagation()}>
            <button className="close-button" onClick={() => setSelectedImage(null)}>
              Close
            </button>

            <div className="detail-image">
              <img src={selectedImage.src} alt={selectedImage.alt} />
            </div>

            <div className="detail-body">
              <p className="collection">{selectedImage.collection}</p>
              <h2>{selectedImage.title}</h2>

              <div className="meta-list">
                {renderMeta("Role", selectedImage.storyRole)}
                {renderMeta("Season", selectedImage.season)}
                {renderMeta("Location", selectedImage.location)}
                {renderMeta("Mood", selectedImage.mood)}
                {renderMeta("Light", selectedImage.light)}
                {renderMeta("Material", selectedImage.material)}
                {renderMeta("Composition", selectedImage.composition)}
                {renderMeta("Import", selectedImage.importSource)}
              </div>

              <div className="tag-row">
                {selectedImage.tags.map((tag) => (
                  <span key={tag}>{tag}</span>
                ))}
              </div>

              {selectedImage.notes && <p className="detail-notes">{selectedImage.notes}</p>}
            </div>
          </article>
        </div>
      )}
    </main>
  );
}

export default App;