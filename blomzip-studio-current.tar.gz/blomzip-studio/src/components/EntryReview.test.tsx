/**
 * @vitest-environment jsdom
 */

import { createRoot, type Root } from "react-dom/client";
import { act } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, beforeEach, afterEach, vi } from "vitest";
import { useState } from "react";
import { EntryReview } from "./EntryReview";
import { MockObservationEngine } from "./observationEngine";
import { FixtureVisionProvider, type VisionProvider } from "../utils/visionProvider";
import { listCanonicalPlaces } from "../data/canonicalPlaces";
import type { Visit } from "../models/blomzip";

const visit: Visit = {
  id: "visit-1",
  placeId: "place-1",
  date: "2026-07-05",
  entries: [
    {
      id: "entry-1",
      imageRecordId: "image-1",
      visitId: "visit-1",
      status: "new",
      notes: "",
      tags: [],
      observations: [
        {
          id: "obs-ai-1",
          entryId: "entry-1",
          type: "Plant",
          confidence: 0.9,
          source: "mock-ai",
          value: "Hydrangea-like bloom",
          createdAt: "2026-07-05T00:00:00.000Z",
          reviewed: false,
        },
      ],
      analysisSuggestions: {
        engine: "mock-observation-engine",
        generatedAt: "2026-07-05T00:00:00.000Z",
        confidence: 0.87,
        categories: ["story-candidate", "by-place", "possible-duplicates"],
        possibleDuplicateEntryIds: ["entry-2"],
      },
      createdAt: "2026-07-05T00:00:00.000Z",
      updatedAt: "2026-07-05T00:00:00.000Z",
    },
    {
      id: "entry-2",
      imageRecordId: "image-2",
      visitId: "visit-1",
      status: "new",
      notes: "",
      tags: [],
      observations: [],
      createdAt: "2026-07-05T00:00:00.000Z",
      updatedAt: "2026-07-05T00:00:00.000Z",
    },
  ],
  imageRecords: [
    {
      id: "image-1",
      filename: "courtyard-01.jpg",
      fileSize: 1200,
      format: "jpeg",
      sourcePath: "courtyard/courtyard-01.jpg",
      width: 1600,
      height: 1200,
      orientation: "landscape",
      mimeType: "image/jpeg",
      timelineIndex: 0,
      captureDate: "2026-07-05T10:30:00.000Z",
      thumbnailUrl: "data:image/gif;base64,R0lGODlhAQABAIAAAAUEBAAAACwAAAAAAQABAAACAkQBADs=",
    },
    {
      id: "image-2",
      filename: "courtyard-02.jpg",
      fileSize: 1600,
      format: "jpeg",
      sourcePath: "courtyard/courtyard-02.jpg",
      width: 1200,
      height: 1600,
      orientation: "portrait",
      mimeType: "image/jpeg",
      timelineIndex: 1,
      thumbnailUrl: "data:image/gif;base64,R0lGODlhAQABAIAAAAUEBAAAACwAAAAAAQABAAACAkQBADs=",
    },
  ],
  imageCount: 2,
  status: "Ready for AI",
};

describe("EntryReview", () => {
  let container: HTMLDivElement;
  let root: Root;

  function getReactProps<ElementType extends Element>(element: ElementType) {
    const propKey = Object.keys(element).find((key) => key.startsWith("__reactProps$"));
    if (!propKey) {
      return null;
    }

    return (element as ElementType & { [key: string]: any })[propKey] as any;
  }

  beforeEach(() => {
    container = document.createElement("div");
    document.body.appendChild(container);
    root = createRoot(container);
  });

  afterEach(() => {
    act(() => {
      root.unmount();
    });
    container.remove();
  });

  it("renders a compact review header with back to archive wording", () => {
    act(() => {
      root.render(<EntryReview visit={visit} onClose={vi.fn()} />);
    });

    expect(container.querySelector('[data-testid="entry-review-header"]')).toBeDefined();
    expect(container.textContent).toContain("Back to archive");
    expect(container.textContent).toContain("Entry");
    expect(container.textContent).toContain("1 of 2");
    expect(container.textContent).toContain("Save status");
    expect(container.textContent).toContain("Review progress");
    expect(container.textContent).not.toContain("Workflow:");
    expect(container.textContent).not.toContain("Next:");
    expect(container.textContent).not.toContain("Finalize visit");
  });

  it("renders the complete image in a bounded region", () => {
    act(() => {
      root.render(<EntryReview visit={visit} />);
    });

    const imageRegion = container.querySelector('[data-testid="entry-review-image-region"]');
    const image = container.querySelector('[data-testid="entry-review-main-image"]') as HTMLImageElement | null;

    expect(imageRegion).toBeDefined();
    expect(image).toBeDefined();
    expect(image?.className).toContain("entry-review-preview-image");
    expect(image?.getAttribute("alt")).toBe("courtyard-01.jpg");
  });

  it("shows AI suggestions fields when analysis suggestions exist", () => {
    const aiRichVisit: Visit = {
      ...visit,
      entries: [
        {
          ...visit.entries[0],
          analysisSuggestions: {
            ...visit.entries[0].analysisSuggestions!,
            categories: ["hero-candidate", "story-candidate", "favorite-candidate", "by-place", "possible-duplicates"],
          },
        },
        visit.entries[1],
      ],
    };

    const html = renderToStaticMarkup(<EntryReview visit={aiRichVisit} />);

    expect(html).toContain("Editorial recommendations");
    expect(html).toContain("Legacy AI suggestion: Hero candidate");
    expect(html).toContain("Legacy AI suggestion: Story candidate");
    expect(html).toContain("Legacy AI suggestion: Favorite candidate");
    expect(html).toContain("Analysis signals");
    expect(html).toContain("Hero candidate");
    expect(html).toContain("Story candidate");
    expect(html).toContain("Favorite candidate");
    expect(html).toContain("Place/group suggestion");
    expect(html).toContain("Analysis confidence");
    expect(html).toContain("General context");
    expect(html).toContain("Suggested observations");
    expect(html).toContain("Possible duplicates");
    expect(html).toContain("Your curation decisions");
  });

  it("renders v0.2 Story and Hero assessments with their own scores, reasons, and evidence", () => {
    const recommendationVisit: Visit = {
      ...visit,
      entries: [
        {
          ...visit.entries[0],
          analysisSuggestions: {
            ...visit.entries[0].analysisSuggestions!,
            recommendations: [
              {
                kind: "story",
                score: 0.88,
                reasons: ["Documents how the courtyard was used.", "Connects a social moment to this place."],
                evidence: [
                  { signal: "human-activity", detail: "People using the seating area" },
                  { signal: "place-coverage", contribution: 0.3 },
                ],
                engine: "vision-engine-v0.2",
                generatedAt: "2026-08-14T00:00:00.000Z",
                analysisVersion: 2,
              },
              {
                kind: "hero",
                score: 0.74,
                reasons: ["Clear spatial overview of the courtyard."],
                evidence: [{ signal: "spatial-overview", detail: "Foreground and background remain readable" }],
                engine: "vision-engine-v0.2",
                generatedAt: "2026-08-14T00:00:00.000Z",
                analysisVersion: 2,
              },
              {
                kind: "favorite",
                score: 0.6,
                reasons: [],
                evidence: [],
                engine: "vision-engine-v0.2",
                generatedAt: "2026-08-14T00:00:00.000Z",
                analysisVersion: 2,
              },
            ],
          },
        },
        visit.entries[1],
      ],
    };

    const html = renderToStaticMarkup(<EntryReview visit={recommendationVisit} />);

    expect(html).toContain("Editorial recommendations");
    expect(html).toContain("Story");
    expect(html).toContain("Score 88%");
    expect(html).toContain("Documents how the courtyard was used.");
    expect(html).toContain("More reasons (1)");
    expect(html).toContain("Hero");
    expect(html).toContain("Score 74%");
    expect(html).toContain("Clear spatial overview of the courtyard.");
    expect(html).toContain("Favorite");
    expect(html).toContain("Score 60%");
    expect(html).toContain("Why this recommendation?");
    expect(html).toContain("Human activity");
    expect(html).toContain("People using the seating area");
    expect(html).toContain("Place coverage");
    expect(html).toContain("Spatial overview");
    expect(html).not.toContain("Analysis confidence:");
    expect(html).not.toContain("General context:");
    expect(html).not.toContain("High visual priority from AI scoring and composition signals.");
  });

  it("can hide and unhide an entry while clearing story/favorite/hero selections", () => {
    const onEntryUpdated = vi.fn();
    const hiddenVisit: Visit = {
      ...visit,
      entries: [
        {
          ...visit.entries[0],
          favorite: true,
          hero: true,
          storySelected: true,
          hidden: false,
        },
        visit.entries[1],
      ],
    };

    act(() => {
      root.render(<EntryReview visit={hiddenVisit} onEntryUpdated={onEntryUpdated} />);
    });

    const hideButton = Array.from(container.querySelectorAll("button")).find((button) => button.textContent?.includes("Hide"));
    expect(hideButton).toBeTruthy();

    act(() => {
      hideButton?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });

    expect(onEntryUpdated).toHaveBeenLastCalledWith(expect.objectContaining({
      id: "entry-1",
      hidden: true,
      favorite: false,
      hero: false,
      storySelected: false,
    }));

    const unhideButton = Array.from(container.querySelectorAll("button")).find((button) => button.textContent?.includes("Unhide"));
    expect(unhideButton).toBeTruthy();

    act(() => {
      unhideButton?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });

    expect(onEntryUpdated).toHaveBeenLastCalledWith(expect.objectContaining({
      id: "entry-1",
      hidden: false,
      favorite: false,
      hero: false,
      storySelected: false,
    }));
  });

  it("shows a privacy blocker and resolves it by excluding the image", () => {
    const onEntryUpdated = vi.fn();
    const privacyVisit: Visit = {
      ...visit,
      entries: [{
        ...visit.entries[0],
        visualAnalysis: {
          signals: [{ signal: "face-detected" as never, confidence: 0.99, detail: "Identifiable face detected", provider: "test", analysisVersion: 1 }],
          provider: "test",
          generatedAt: "2026-01-01T00:00:00.000Z",
          analysisVersion: 1,
        },
        privacyStatus: "review-required",
      }],
    };

    act(() => {
      root.render(<EntryReview visit={privacyVisit} onEntryUpdated={onEntryUpdated} />);
    });

    expect(container.querySelector("[data-testid='panel-privacy-status']")?.textContent).toContain("blocked from publication");
    const excludeButton = Array.from(container.querySelectorAll("button")).find((button) => button.textContent === "Exclude from publication");
    expect(excludeButton).toBeTruthy();

    act(() => {
      excludeButton?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });

    expect(onEntryUpdated).toHaveBeenLastCalledWith(expect.objectContaining({
      hidden: true,
      privacyStatus: "privacy-safe",
    }));
  });

  it("does not fabricate v0.2 reasons and treats an empty recommendation list as authoritative", () => {
    const emptyRecommendationVisit: Visit = {
      ...visit,
      entries: [
        {
          ...visit.entries[0],
          analysisSuggestions: {
            ...visit.entries[0].analysisSuggestions!,
            categories: ["story-candidate", "hero-candidate"],
            recommendations: [],
          },
        },
        visit.entries[1],
      ],
    };

    const html = renderToStaticMarkup(<EntryReview visit={emptyRecommendationVisit} />);

    expect(html).toContain("No Story recommendation from this analysis.");
    expect(html).not.toContain("Legacy AI suggestion");
    expect(html).not.toContain("High visual priority from AI scoring and composition signals.");
  });

  it("shows legacy editorial categories without a fabricated recommendation score or evidence", () => {
    const html = renderToStaticMarkup(<EntryReview visit={visit} />);

    expect(html).toContain("Legacy AI suggestion: Story candidate");
    expect(html).toContain("Detailed recommendation evidence is not available for this analysis.");
    expect(html).not.toContain("Score 87%");
    expect(html).not.toContain("Why this recommendation?");
  });

  it("does not show AI suggestion panel when no analysis suggestions exist", () => {
    const html = renderToStaticMarkup(
      <EntryReview
        visit={{
          ...visit,
          entries: [{ ...visit.entries[0], analysisSuggestions: undefined }, visit.entries[1]],
        }}
      />
    );

    expect(html).not.toContain("AI suggestions");
    expect(html).not.toContain("Place/group suggestion");
  });

  it("shows confidence only when existing analysis data includes it", () => {
    const noConfidenceVisit: Visit = {
      ...visit,
      entries: [
        {
          ...visit.entries[0],
          analysisSuggestions: {
            ...(visit.entries[0].analysisSuggestions as NonNullable<typeof visit.entries[0]["analysisSuggestions"]>),
            confidence: undefined as unknown as number,
          },
        },
        visit.entries[1],
      ],
    };

    const html = renderToStaticMarkup(<EntryReview visit={noConfidenceVisit} />);
    expect(html).toContain("Analysis signals");
    expect(html).not.toContain("Analysis confidence:");
  });

  it("keeps AI suggestions distinct from human curation state", () => {
    const aiVisit: Visit = {
      ...visit,
      entries: [
        {
          ...visit.entries[0],
          analysisSuggestions: {
            ...visit.entries[0].analysisSuggestions!,
            categories: ["hero-candidate", "story-candidate", "favorite-candidate"],
          },
          hero: false,
          favorite: false,
          storySelected: false,
        },
        visit.entries[1],
      ],
    };

    const html = renderToStaticMarkup(<EntryReview visit={aiVisit} />);

    expect(html).toContain("Hero candidate");
    expect(html).toContain("Story candidate");
    expect(html).toContain("Favorite candidate");
    expect(html).toContain("Your curation decisions");
    expect(html).toContain("Mark as hero");
    expect(html).toContain("Mark as favorite");
    expect(html).toContain("Select for Story");
  });

  it("keeps Previous and Next in one unified navigation region without duplication", () => {
    act(() => {
      root.render(<EntryReview visit={visit} />);
    });

    const nav = container.querySelector('[data-testid="entry-review-navigation"]');
    const allPreviousButtons = Array.from(container.querySelectorAll("button")).filter((button) => button.textContent === "Previous");
    const allNextButtons = Array.from(container.querySelectorAll("button")).filter((button) => button.textContent === "Next");

    expect(nav).toBeDefined();
    expect(nav?.textContent).toContain("Entry 1 of 2");
    expect(allPreviousButtons).toHaveLength(1);
    expect(allNextButtons).toHaveLength(1);
    expect(container.textContent).not.toContain("Next image");
  });

  it("renders review controls in the expected vertical order", () => {
    act(() => {
      root.render(<EntryReview visit={visit} />);
    });

    const panel = container.querySelector('[data-testid="entry-review-panel"]') as HTMLElement | null;
    const sequence = [
      "panel-filename",
      "panel-editorial-recommendations",
      "panel-ai-suggestions",
      "panel-curation-controls",
      "panel-notes",
      "panel-tags",
      "panel-observations",
      "panel-mark-reviewed",
      "panel-captured-date",
      "panel-essential-metadata",
    ].map((testId) => panel?.querySelector(`[data-testid="${testId}"]`) as HTMLElement | null);

    expect(sequence.every(Boolean)).toBe(true);

    const order = sequence.map((node) => Array.from(panel?.children ?? []).indexOf(node as Element));
    for (let index = 0; index < order.length - 1; index += 1) {
      expect(order[index]).toBeLessThan(order[index + 1] ?? 0);
    }
  });

  it("keeps current entry selected while editing notes and tags", () => {
    const onEntryUpdated = vi.fn();

    function StatefulReview() {
      const [statefulVisit, setStatefulVisit] = useState(visit);

      return (
        <EntryReview
          visit={statefulVisit}
          onEntryUpdated={(updatedEntry) => {
            onEntryUpdated(updatedEntry);
            setStatefulVisit((currentVisit) => ({
              ...currentVisit,
              entries: currentVisit.entries.map((entryItem) =>
                entryItem.id === updatedEntry.id ? updatedEntry : entryItem
              ),
            }));
          }}
        />
      );
    }

    act(() => {
      root.render(<StatefulReview />);
    });

    const nextButton = Array.from(container.querySelectorAll("button")).find((button) => button.textContent === "Next");

    act(() => {
      nextButton?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });

    expect(container.textContent).toContain("Entry 2 of 2");
    expect(container.textContent).toContain("courtyard-02.jpg");

    const noteField = container.querySelector("textarea");
    const tagField = Array.from(container.querySelectorAll("input")).find((input) =>
      input.getAttribute("placeholder")?.includes("tags")
    ) as HTMLInputElement | undefined;

    act(() => {
      const noteProps = noteField ? getReactProps(noteField as HTMLTextAreaElement) : null;
      noteProps?.onChange?.({ target: { value: "Updated note" } });
    });

    act(() => {
      const tagProps = tagField ? getReactProps(tagField) : null;
      tagProps?.onChange?.({ target: { value: "tag-a, tag-b" } });
    });

    expect(container.textContent).toContain("Entry 2 of 2");
    expect(container.textContent).toContain("courtyard-02.jpg");
    expect(onEntryUpdated).toHaveBeenCalled();
  });

  it("auto-advances to the next entry after marking the current one reviewed", () => {
    const onEntryUpdated = vi.fn();

    act(() => {
      root.render(<EntryReview visit={visit} onEntryUpdated={onEntryUpdated} />);
    });

    const reviewButton = Array.from(container.querySelectorAll("button")).find((button) =>
      button.textContent === "Mark entry reviewed"
    );

    act(() => {
      reviewButton?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });

    expect(container.textContent).toContain("Entry 2 of 2");
    expect(container.textContent).toContain("courtyard-02.jpg");
    expect(onEntryUpdated).toHaveBeenCalledWith(expect.objectContaining({
      id: "entry-1",
      reviewed: true,
    }));
  });

  it("supports keyboard shortcuts for navigation and curation", () => {
    act(() => {
      root.render(<EntryReview visit={visit} />);
    });

    act(() => {
      window.dispatchEvent(new KeyboardEvent("keydown", { key: "ArrowRight", bubbles: true }));
    });

    expect(container.textContent).toContain("Entry 2 of 2");

    act(() => {
      window.dispatchEvent(new KeyboardEvent("keydown", { key: "ArrowLeft", bubbles: true }));
    });

    expect(container.textContent).toContain("Entry 1 of 2");

    act(() => {
      window.dispatchEvent(new KeyboardEvent("keydown", { key: "f", bubbles: true }));
    });

    expect(container.textContent).toContain("Favorite ✓");
  });

  it("does not trigger keyboard shortcuts while typing in a text field", () => {
    act(() => {
      root.render(<EntryReview visit={visit} />);
    });

    const noteField = container.querySelector("textarea") as HTMLTextAreaElement | null;
    const noteProps = noteField ? getReactProps(noteField) : null;

    act(() => {
      noteProps?.onChange?.({ target: { value: "Typing a note" } });
    });

    act(() => {
      noteField?.dispatchEvent(new KeyboardEvent("keydown", { key: "f", bubbles: true }));
    });

    expect(container.textContent).toContain("Pending review");
    expect(container.textContent).not.toContain("Favorite ✓");
  });

  it("preserves edits while auto-advancing and stops on the final entry", () => {
    function StatefulReview() {
      const [statefulVisit, setStatefulVisit] = useState(visit);

      return (
        <EntryReview
          visit={statefulVisit}
          onEntryUpdated={(updatedEntry) => {
            setStatefulVisit((currentVisit) => ({
              ...currentVisit,
              entries: currentVisit.entries.map((entryItem) =>
                entryItem.id === updatedEntry.id ? updatedEntry : entryItem
              ),
            }));
          }}
        />
      );
    }

    act(() => {
      root.render(<StatefulReview />);
    });

    const noteField = container.querySelector("textarea") as HTMLTextAreaElement | null;
    const noteProps = noteField ? getReactProps(noteField) : null;

    act(() => {
      noteProps?.onChange?.({ target: { value: "Important edit" } });
    });

    act(() => {
      const reviewButton = Array.from(container.querySelectorAll("button")).find((button) =>
        button.textContent === "Mark entry reviewed"
      );
      reviewButton?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });

    expect(container.textContent).toContain("Entry 2 of 2");
    expect(container.textContent).toContain("courtyard-02.jpg");

    act(() => {
      const previousButton = Array.from(container.querySelectorAll("button")).find((button) => button.textContent === "Previous");
      previousButton?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });

    expect(container.textContent).toContain("Important edit");

    act(() => {
      const nextButton = Array.from(container.querySelectorAll("button")).find((button) => button.textContent === "Next");
      nextButton?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });

    expect(container.textContent).toContain("Entry 2 of 2");

    act(() => {
      const reviewButton = Array.from(container.querySelectorAll("button")).find((button) =>
        button.textContent === "Mark entry reviewed"
      );
      reviewButton?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });

    expect(container.textContent).toContain("Entry 2 of 2");
    expect(container.textContent).toContain("Finalize visit");
  });

  it("toggles Favorite, Hero and Story on and off with clear labels", () => {
    const onEntryUpdated = vi.fn();

    act(() => {
      root.render(<EntryReview visit={visit} onEntryUpdated={onEntryUpdated} />);
    });

    const findButtonByText = (text: string) =>
      Array.from(container.querySelectorAll("button")).find((button) => button.textContent === text);

    act(() => {
      findButtonByText("Mark as favorite")?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
      findButtonByText("Mark as hero")?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
      findButtonByText("Select for Story")?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });

    expect(container.textContent).toContain("Favorite ✓");
    expect(container.textContent).toContain("Hero ✓");
    expect(container.textContent).toContain("Selected for Story ✓");

    act(() => {
      findButtonByText("Favorite ✓")?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
      findButtonByText("Hero ✓")?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
      findButtonByText("Selected for Story ✓")?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });

    expect(container.textContent).toContain("Mark as favorite");
    expect(container.textContent).toContain("Mark as hero");
    expect(container.textContent).toContain("Select for Story");
    expect(onEntryUpdated).toHaveBeenCalled();
  });

  it("supports observation accept, edit and reject in the same panel", () => {
    const onEntryUpdated = vi.fn();

    act(() => {
      root.render(<EntryReview visit={visit} onEntryUpdated={onEntryUpdated} />);
    });

    const observationField = container.querySelector(".entry-review-observation-input") as HTMLInputElement | null;
    const acceptButton = Array.from(container.querySelectorAll("button")).find((button) => button.textContent === "Accept");

    act(() => {
      const observationProps = observationField ? getReactProps(observationField) : null;
      observationProps?.onChange?.({ target: { value: "Edited observation" } });
    });

    act(() => {
      acceptButton?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });

    expect(onEntryUpdated).toHaveBeenCalled();
    expect(container.textContent).toContain("Accepted");
  });

  it("marks the current entry as reviewed", () => {
    const onEntryUpdated = vi.fn();

    act(() => {
      root.render(<EntryReview visit={visit} onEntryUpdated={onEntryUpdated} />);
    });

    const reviewButton = Array.from(container.querySelectorAll("button")).find((button) =>
      button.textContent === "Mark entry reviewed"
    );

    act(() => {
      reviewButton?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });

    expect(onEntryUpdated).toHaveBeenCalledWith(expect.objectContaining({
      id: "entry-1",
      reviewed: true,
    }));
  });

  it("shows finalize only when relevant and finalizes after all entries are reviewed", () => {
    const onVisitFinalized = vi.fn();

    act(() => {
      root.render(<EntryReview visit={visit} onVisitFinalized={onVisitFinalized} />);
    });

    expect(Array.from(container.querySelectorAll("button")).some((button) => button.textContent === "Finalize visit")).toBe(false);

    const markReviewed = Array.from(container.querySelectorAll("button")).find((button) =>
      button.textContent === "Mark entry reviewed"
    );

    act(() => {
      markReviewed?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });

    act(() => {
      const nextButton = Array.from(container.querySelectorAll("button")).find((button) => button.textContent === "Next");
      nextButton?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });

    const secondReviewButton = Array.from(container.querySelectorAll("button")).find((button) =>
      button.textContent === "Mark entry reviewed"
    );

    act(() => {
      secondReviewButton?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });

    const finalizeButton = Array.from(container.querySelectorAll("button")).find((button) =>
      button.textContent === "Finalize visit"
    );

    expect(finalizeButton).toBeDefined();

    act(() => {
      finalizeButton?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    });

    expect(onVisitFinalized).toHaveBeenCalledWith(expect.objectContaining({
      status: "Finalized",
      entries: expect.arrayContaining([
        expect.objectContaining({ reviewed: true }),
        expect.objectContaining({ reviewed: true }),
      ]),
    }));
  });

  it("creates mock observations for the matching entry", () => {
    const observations = new MockObservationEngine().generateObservations("entry-1");

    expect(observations.length).toBeGreaterThan(0);
    expect(observations.every((observation) => observation.entryId === "entry-1")).toBe(true);
    expect(observations.every((observation) => observation.source === "mock-ai")).toBe(true);
  });

  it("shows Not analyzed by default and reveals inspectable signals separately from mock observations after a curator-triggered analysis", async () => {
    const fixtureProvider = new FixtureVisionProvider();

    await act(async () => {
      root.render(<EntryReview visit={visit} visionProvider={fixtureProvider} />);
    });

    const statusBefore = container.querySelector('[data-testid="visual-analysis-status"]');
    expect(statusBefore?.textContent).toContain("Not analyzed");

    const analyzeButton = Array.from(container.querySelectorAll("button")).find((button) => button.textContent === "Analyze image");

    await act(async () => {
      analyzeButton?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
      await Promise.resolve();
    });

    const statusAfter = container.querySelector('[data-testid="visual-analysis-status"]');
    expect(statusAfter?.textContent).toContain("Analysis available");

    const signalsSection = container.querySelector('[data-testid="visual-analysis-signals"]');
    expect(signalsSection?.textContent).toContain("Human activity");
    expect(signalsSection?.textContent).toContain("92%");
    expect(signalsSection?.textContent).toContain("Two people are interacting outdoors.");

    // Distinct from the legacy mock "Analysis signals" panel driven by MockObservationEngine.
    const legacyPanel = container.querySelector('[data-testid="panel-ai-suggestions"]');
    expect(legacyPanel?.textContent).not.toContain("Two people are interacting outdoors.");
  });

  it("shows Analysis failed without corrupting the entry when the provider rejects", async () => {
    const failingProvider: VisionProvider = {
      id: "failing-test-provider",
      analyzeImage: () => Promise.reject(new Error("No genuine image-analysis provider is configured.")),
    };
    const onEntryUpdated = vi.fn();

    await act(async () => {
      root.render(<EntryReview visit={visit} visionProvider={failingProvider} onEntryUpdated={onEntryUpdated} />);
    });

    const analyzeButton = Array.from(container.querySelectorAll("button")).find((button) => button.textContent === "Analyze image");

    await act(async () => {
      analyzeButton?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
      await Promise.resolve();
    });

    const status = container.querySelector('[data-testid="visual-analysis-status"]');
    expect(status?.textContent).toContain("Analysis failed");
    expect(status?.textContent).toContain("No genuine image-analysis provider is configured.");
    expect(onEntryUpdated).not.toHaveBeenCalled();
  });

  it("re-runs Story after visual analysis and shows the recomputed capped score honestly", async () => {
    const storyVisit: Visit = {
      id: "visit-story",
      placeId: "rock-garden",
      date: "2026-01-01",
      entries: [
        {
          id: "entry-story-1",
          imageRecordId: "image-story-1",
          visitId: "visit-story",
          status: "new",
          notes: "",
          tags: [],
          observations: [],
          analysisSuggestions: {
            engine: "mock-observation-engine",
            generatedAt: "2026-08-14T00:00:00.000Z",
            confidence: 0.9,
            categories: [],
            recommendations: [
              {
                kind: "story",
                score: 0.56,
                reasons: ["Provides an early chronological reference for this place."],
                evidence: [{ signal: "chronological-anchor", contribution: 0.38, detail: "31 days across available dated photographs" }],
                engine: "vision-engine-v0.2-story-context",
                generatedAt: "2026-08-14T00:00:00.000Z",
                analysisVersion: 2,
              },
            ],
          },
          createdAt: "2026-08-14T00:00:00.000Z",
          updatedAt: "2026-08-14T00:00:00.000Z",
        },
        {
          id: "entry-story-2",
          imageRecordId: "image-story-2",
          visitId: "visit-story",
          status: "new",
          notes: "",
          tags: [],
          observations: [],
          analysisSuggestions: {
            engine: "mock-observation-engine",
            generatedAt: "2026-08-14T00:00:00.000Z",
            confidence: 0.9,
            categories: [],
          },
          createdAt: "2026-08-14T00:00:00.000Z",
          updatedAt: "2026-08-14T00:00:00.000Z",
        },
      ],
      imageRecords: [
        {
          id: "image-story-1",
          placeId: "rock-garden",
          filename: "rock-early.jpg",
          fileSize: 100_000,
          format: "jpg",
          sourcePath: "rock-early.jpg",
          captureDate: "2026-01-01T10:00:00.000Z",
          timelineIndex: 0,
          width: 1200,
          height: 800,
        },
        {
          id: "image-story-2",
          placeId: "rock-garden",
          filename: "rock-late.jpg",
          fileSize: 110_000,
          format: "jpg",
          sourcePath: "rock-late.jpg",
          captureDate: "2026-02-01T10:00:00.000Z",
          timelineIndex: 1,
          width: 1200,
          height: 800,
        },
      ],
      imageCount: 2,
      status: "Ready for AI",
    };

    await act(async () => {
      root.render(<EntryReview visit={storyVisit} visionProvider={new FixtureVisionProvider()} />);
    });

    expect(container.textContent).toContain("Score 56%");

    const analyzeButton = Array.from(container.querySelectorAll("button")).find((button) => button.textContent === "Analyze image");

    await act(async () => {
      analyzeButton?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
      await Promise.resolve();
    });

    // Recomputing from full archive context (chronological anchor + temporal separation +
    // place coverage = 0.88) plus the human-activity visual contribution (+0.14) caps at 100%.
    expect(container.textContent).toContain("Score 100%");
  });

  it("renders a Canonical place selector defaulting to Unassigned for an image with no placeId", () => {
    act(() => {
      root.render(<EntryReview visit={visit} />);
    });

    const select = container.querySelector('[data-testid="canonical-place-select"]') as HTMLSelectElement | null;
    expect(select).toBeTruthy();
    expect(select?.value).toBe("");
    expect(container.textContent).toContain("Canonical place");
  });

  it("uses the dark on-light label class for curation-panel labels instead of the light sidebar text color", () => {
    act(() => {
      root.render(<EntryReview visit={visit} />);
    });

    const canonicalPlaceLabel = container.querySelector('[data-testid="panel-canonical-place"] span');
    const notesLabel = container.querySelector('[data-testid="panel-notes"] span');
    const tagsLabel = container.querySelector('[data-testid="panel-tags"] span');

    expect(canonicalPlaceLabel?.className).toContain("entry-review-label-on-light");
    expect(notesLabel?.className).toContain("entry-review-label-on-light");
    expect(tagsLabel?.className).toContain("entry-review-label-on-light");
  });

  it("populates every canonical place option from the shared canonical-place data source", () => {
    act(() => {
      root.render(<EntryReview visit={visit} />);
    });

    const select = container.querySelector('[data-testid="canonical-place-select"]') as HTMLSelectElement | null;
    const optionLabels = Array.from(select?.querySelectorAll("option") ?? []).map((option) => option.textContent);

    expect(optionLabels[0]).toBe("Unassigned");
    expect(optionLabels.slice(1)).toEqual(listCanonicalPlaces().map((place) => place.displayName));
  });

  it("assigning a canonical place updates only the current image record via the callback", () => {
    const onImageRecordPlaceChanged = vi.fn();
    const onEntryUpdated = vi.fn();

    act(() => {
      root.render(<EntryReview visit={visit} onImageRecordPlaceChanged={onImageRecordPlaceChanged} onEntryUpdated={onEntryUpdated} />);
    });

    const select = container.querySelector('[data-testid="canonical-place-select"]') as HTMLSelectElement | null;

    act(() => {
      if (select) select.value = "rock-garden";
      select?.dispatchEvent(new Event("change", { bubbles: true }));
    });

    expect(onImageRecordPlaceChanged).toHaveBeenCalledTimes(1);
    expect(onImageRecordPlaceChanged).toHaveBeenCalledWith("image-1", "rock-garden");
    // Canonical place assignment is not an Entry field change; it must not go through onEntryUpdated.
    expect(onEntryUpdated).not.toHaveBeenCalled();
  });

  it("displays the previously assigned canonical place after the visit prop updates", () => {
    const assignedVisit: Visit = {
      ...visit,
      imageRecords: (visit.imageRecords ?? []).map((record) =>
        record.id === "image-1" ? { ...record, placeId: "rock-garden" } : record
      ),
    };

    act(() => {
      root.render(<EntryReview visit={assignedVisit} />);
    });

    const select = container.querySelector('[data-testid="canonical-place-select"]') as HTMLSelectElement | null;
    expect(select?.value).toBe("rock-garden");
  });

  it("changing an already-assigned canonical place calls back with the new place id", () => {
    const assignedVisit: Visit = {
      ...visit,
      imageRecords: (visit.imageRecords ?? []).map((record) =>
        record.id === "image-1" ? { ...record, placeId: "rock-garden" } : record
      ),
    };
    const onImageRecordPlaceChanged = vi.fn();

    act(() => {
      root.render(<EntryReview visit={assignedVisit} onImageRecordPlaceChanged={onImageRecordPlaceChanged} />);
    });

    const select = container.querySelector('[data-testid="canonical-place-select"]') as HTMLSelectElement | null;

    act(() => {
      if (select) select.value = "house-wall";
      select?.dispatchEvent(new Event("change", { bubbles: true }));
    });

    expect(onImageRecordPlaceChanged).toHaveBeenCalledWith("image-1", "house-wall");
  });

  it("selecting Unassigned clears the canonical place", () => {
    const assignedVisit: Visit = {
      ...visit,
      imageRecords: (visit.imageRecords ?? []).map((record) =>
        record.id === "image-1" ? { ...record, placeId: "rock-garden" } : record
      ),
    };
    const onImageRecordPlaceChanged = vi.fn();

    act(() => {
      root.render(<EntryReview visit={assignedVisit} onImageRecordPlaceChanged={onImageRecordPlaceChanged} />);
    });

    const select = container.querySelector('[data-testid="canonical-place-select"]') as HTMLSelectElement | null;

    act(() => {
      if (select) select.value = "";
      select?.dispatchEvent(new Event("change", { bubbles: true }));
    });

    expect(onImageRecordPlaceChanged).toHaveBeenCalledWith("image-1", null);
  });

  it("does not mark the entry reviewed or change unrelated curation state when assigning a canonical place", () => {
    const onImageRecordPlaceChanged = vi.fn();

    act(() => {
      root.render(<EntryReview visit={visit} onImageRecordPlaceChanged={onImageRecordPlaceChanged} />);
    });

    expect(container.textContent).toContain("Pending review");
    expect(container.textContent).toContain("Favorite not selected");
    expect(container.textContent).toContain("Hero not selected");
    expect(container.textContent).toContain("Story not selected");

    const select = container.querySelector('[data-testid="canonical-place-select"]') as HTMLSelectElement | null;

    act(() => {
      if (select) select.value = "rock-garden";
      select?.dispatchEvent(new Event("change", { bubbles: true }));
    });

    expect(container.textContent).toContain("Pending review");
    expect(container.textContent).toContain("Favorite not selected");
    expect(container.textContent).toContain("Hero not selected");
    expect(container.textContent).toContain("Story not selected");
    expect(Array.from(container.querySelectorAll("button")).some((button) => button.textContent === "Mark entry reviewed")).toBe(true);
  });
});
